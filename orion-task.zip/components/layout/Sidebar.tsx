
import React from 'react';
import { NavLink } from 'react-router-dom';
import { COLORS, MOCK_PROJECTS, MOCK_USERS } from '../../constants';
import { DashboardIcon } from '../icons/DashboardIcon';
import { ProjectsIcon } from '../icons/ProjectsIcon';
import { TasksIcon } from '../icons/TasksIcon';
import { CalendarIcon } from '../icons/CalendarIcon';
import { NotesIcon } from '../icons/NotesIcon';
import { TeamsIcon } from '../icons/TeamsIcon';
import { SettingsIcon } from '../icons/SettingsIcon';
import { LogoutIcon } from '../icons/LogoutIcon';
import { Avatar } from '../ui/Avatar';
import { ChevronDownIcon } from '../icons/ChevronDownIcon';
import { ChevronRightIcon } from '../icons/ChevronRightIcon'; 
import { PlusIcon } from '../icons/PlusIcon';
import { MenuIcon } from '../icons/MenuIcon';
import { CategoryIcon } from '../icons/CategoryIcon'; // Import CategoryIcon


interface SidebarProps {
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
}

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  isSidebarOpen: boolean;
}

const NavItem: React.FC<NavItemProps> = ({ to, icon, label, isSidebarOpen }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `flex items-center py-2.5 px-4 rounded-md transition-colors duration-200
       ${isSidebarOpen ? 'justify-start' : 'justify-center'}
       ${isActive ? `bg-[${COLORS.primary}] text-white shadow-lg` : `text-gray-400 hover:bg-gray-700 hover:text-white`}`
    }
    title={label}
  >
    {icon}
    {isSidebarOpen && <span className="ml-3 text-sm font-medium">{label}</span>}
  </NavLink>
);


export const Sidebar: React.FC<SidebarProps> = ({ isSidebarOpen, toggleSidebar }) => {
  const currentUser = MOCK_USERS[0]; 
  const favoriteProjects = MOCK_PROJECTS.filter(p => p.isFavorite);
  const [showAdminMenu, setShowAdminMenu] = React.useState(false);


  return (
    <div
      className={`fixed inset-y-0 left-0 z-30 flex flex-col bg-[${COLORS.sidebarBg}] shadow-xl transition-all duration-300 ease-in-out ${
        isSidebarOpen ? 'w-64' : 'w-20'
      }`}
    >
      {/* Logo and Toggle */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-gray-700">
        {isSidebarOpen && (
          <div className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-8 h-8 text-[${COLORS.primary}]`}>
              <path d="M12.378 1.602a.75.75 0 00-.756 0L3.366 6.198a.75.75 0 00-.366.648V16.5a.75.75 0 00.75.75h16.5a.75.75 0 00.75-.75V6.846a.75.75 0 00-.366-.648L12.378 1.602zM12 15.75a3.75 3.75 0 100-7.5 3.75 3.75 0 000 7.5z" />
              <path d="M21.728 8.603A3.732 3.732 0 0021 8.25a.75.75 0 00-1.06.04L18.47 9.76A3.732 3.732 0 0018 9.75a.75.75 0 00-.942.41l-1.355 2.452a.75.75 0 00.294 1.008l1.008.504a.75.75 0 00.99-.233l.638-1.006A3.732 3.732 0 0019.5 12.75a.75.75 0 00.41.06l2.452-.49a.75.75 0 00.503-1.063l-.503-1.008a.75.75 0 00-1.135-.648zM2.272 8.603A3.732 3.732 0 013 8.25a.75.75 0 011.06.04L5.53 9.76A3.732 3.732 0 016 9.75a.75.75 0 01.942.41l1.355 2.452a.75.75 0 01-.294 1.008l-1.008.504a.75.75 0 01-.99-.233L5.397 12.9A3.732 3.732 0 014.5 12.75a.75.75 0 01-.41.06L1.638 13.3a.75.75 0 01-.503-1.063l.503-1.008a.75.75 0 011.135-.648z" />
            </svg>
            <span className={`ml-2 text-xl font-bold text-white`}>OrionTask</span>
          </div>
        )}
        <button onClick={toggleSidebar} className="p-2 text-gray-400 rounded-md hover:bg-gray-700 focus:outline-none">
          <MenuIcon className="w-6 h-6" />
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        <NavItem to="/" icon={<DashboardIcon className="w-5 h-5" />} label="Dashboard" isSidebarOpen={isSidebarOpen}/>
        <NavItem to="/projects" icon={<ProjectsIcon className="w-5 h-5" />} label="Projects" isSidebarOpen={isSidebarOpen}/>
        <NavItem to="/tasks" icon={<TasksIcon className="w-5 h-5" />} label="My Tasks" isSidebarOpen={isSidebarOpen}/>
        <NavItem to="/calendar" icon={<CalendarIcon className="w-5 h-5" />} label="Calendar" isSidebarOpen={isSidebarOpen}/>
        <NavItem to="/notes" icon={<NotesIcon className="w-5 h-5" />} label="Notes" isSidebarOpen={isSidebarOpen}/>
        <NavItem to="/teams" icon={<TeamsIcon className="w-5 h-5" />} label="Teams" isSidebarOpen={isSidebarOpen}/>
        <NavItem to="/ai-features" icon={<PlusIcon className="w-5 h-5" />} label="AI Features" isSidebarOpen={isSidebarOpen}/>

        {isSidebarOpen && favoriteProjects.length > 0 && (
          <div className="pt-4 mt-4 border-t border-gray-700">
            <h3 className="px-4 mb-2 text-xs font-semibold tracking-wider text-gray-500 uppercase">
              Favorites
            </h3>
            {favoriteProjects.map((project) => (
              <NavLink
                key={project.projectId}
                to={`/projects/${project.projectId}`}
                 className={({ isActive }) =>
                  `flex items-center py-2 px-4 text-sm rounded-md
                   ${isActive ? `text-[${COLORS.primary}] font-semibold` : `text-gray-400 hover:text-white`}`
                }
              >
                <span className="w-2 h-2 mr-3 rounded-full bg-green-400"></span>
                {project.projectName}
              </NavLink>
            ))}
          </div>
        )}
        <div className="pt-4 mt-4 border-t border-gray-700">
            <button
                onClick={() => setShowAdminMenu(!showAdminMenu)}
                className="flex items-center justify-between w-full py-2 px-4 text-gray-400 hover:bg-gray-700 hover:text-white rounded-md"
            >
                <div className="flex items-center">
                    <SettingsIcon className="w-5 h-5" />
                    {isSidebarOpen && <span className="ml-3 text-sm font-medium">Admin</span>}
                </div>
                {isSidebarOpen && (showAdminMenu ? <ChevronDownIcon className="w-4 h-4" /> : <ChevronRightIcon className="w-4 h-4" />)}
            </button>
            {showAdminMenu && isSidebarOpen && (
                <div className="pl-4 mt-1 space-y-1"> {/* Adjusted padding for better visual hierarchy */}
                    <NavLink 
                        to="/admin/tags" 
                        className={({ isActive }) => `flex items-center py-1.5 px-4 text-sm rounded-md ${isActive ? `text-[${COLORS.primary}] bg-gray-700` : 'text-gray-400 hover:text-white hover:bg-gray-700'}`}
                    >
                        <span className="w-5 h-5 mr-2 opacity-0"></span> {/* Placeholder for icon alignment */}
                        Manage Tags
                    </NavLink>
                    <NavLink 
                        to="/admin/categories" 
                        className={({ isActive }) => `flex items-center py-1.5 px-4 text-sm rounded-md ${isActive ? `text-[${COLORS.primary}] bg-gray-700` : 'text-gray-400 hover:text-white hover:bg-gray-700'}`}
                    >
                         <CategoryIcon className="w-4 h-4 mr-2 text-gray-500" /> {/* Example usage */}
                         Manage Categories
                    </NavLink>
                </div>
            )}
        </div>
      </nav>

      <div className={`p-4 border-t border-gray-700 ${isSidebarOpen ? '' : 'flex flex-col items-center'}`}>
        <div className={`flex items-center ${isSidebarOpen ? '' : 'flex-col space-y-2'}`}>
          <Avatar user={currentUser} size="md" />
          {isSidebarOpen && (
            <div className="ml-3">
              <p className="text-sm font-semibold text-white">{currentUser.firstName} {currentUser.lastName}</p>
              <p className="text-xs text-gray-400">{currentUser.email}</p>
            </div>
          )}
        </div>
        <div className={`mt-3 space-y-1 ${isSidebarOpen ? '' : 'flex flex-col items-center'}`}>
           <NavLink
            to="/settings"
            className={`flex items-center py-2 px-2 rounded-md text-gray-400 hover:bg-gray-700 hover:text-white ${isSidebarOpen ? 'w-full' : ''}`}
            title="Settings"
          >
            <SettingsIcon className={`w-5 h-5 ${isSidebarOpen ? '' : 'mx-auto'}`} />
            {isSidebarOpen && <span className="ml-3 text-sm">Settings</span>}
          </NavLink>
          <button 
            className={`flex items-center py-2 px-2 rounded-md text-gray-400 hover:bg-red-600 hover:text-white ${isSidebarOpen ? 'w-full' : ''}`}
            title="Logout"
            onClick={() => alert('Logout clicked')}
          >
            <LogoutIcon className={`w-5 h-5 ${isSidebarOpen ? '' : 'mx-auto'}`} />
            {isSidebarOpen && <span className="ml-3 text-sm">Logout</span>}
          </button>
        </div>
      </div>
    </div>
  );
};


import React, { useState, useEffect } from 'react';
import { SearchIcon } from '../icons/SearchIcon';
import { BellIcon } from '../icons/BellIcon';
import { PlusIcon } from '../icons/PlusIcon';
import { Avatar } from '../ui/Avatar';
import { MOCK_USERS, COLORS } from '../../constants';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface TopBarProps {
  onSidebarToggle: () => void; // For mobile hamburger
}

export const TopBar: React.FC<TopBarProps> = ({ onSidebarToggle }) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const currentUser = MOCK_USERS[0]; // Placeholder

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formattedTime = currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const formattedDate = currentTime.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });

  return (
    <header className="sticky top-0 z-20 h-16 bg-[rgba(22,27,34,0.8)] backdrop-blur-md border-b border-gray-700 flex items-center justify-between px-4 md:px-6">
      <div className="flex items-center">
        {/* Hamburger for mobile - will be shown via Layout.tsx logic */}
         {/* <button onClick={onSidebarToggle} className="md:hidden mr-3 text-gray-400 hover:text-white">
          <MenuIcon className="w-6 h-6" />
        </button> */}
        {/* Global Search */}
        <div className="relative hidden md:block">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <SearchIcon className="w-5 h-5 text-gray-400" />
          </div>
          <Input
            type="search"
            placeholder="Search tasks, projects..."
            className="pl-10 pr-4 py-2 w-64 lg:w-96 !bg-opacity-50 !bg-[#0D1117] !border-gray-600 focus:!ring-[${COLORS.primary}] focus:!border-[${COLORS.primary}]"
            wrapperClassName="!mb-0"
          />
        </div>
      </div>

      <div className="flex items-center space-x-3 md:space-x-5">
        {/* Create Button */}
        <Button variant="primary" size="sm" leftIcon={<PlusIcon className="w-4 h-4" />}>
          Create
        </Button>

        {/* Time and Date */}
        <div className="hidden lg:flex items-center text-sm text-gray-400">
          <span>{formattedTime}</span>
          <span className="mx-1.5">·</span>
          <span>{formattedDate}</span>
        </div>
        
        {/* Notifications */}
        <button className="relative p-2 text-gray-400 hover:text-white rounded-full hover:bg-gray-700 transition-colors">
          <BellIcon className="w-6 h-6" />
          <span className="absolute top-1 right-1.5 flex h-2.5 w-2.5">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full bg-[${COLORS.primary}] opacity-75`}></span>
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 bg-[${COLORS.primary}]`}></span>
          </span>
        </button>

        {/* User Avatar - hidden on mobile, shown in sidebar or a different menu */}
        <div className="hidden md:block">
            <Avatar user={currentUser} size="md" />
        </div>
      </div>
    </header>
  );
};

import React, { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { MenuIcon } from '../icons/MenuIcon'; // For mobile toggle in TopBar if needed

export const Layout: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 768); // Default open on desktop

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 768) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };
    window.addEventListener('resize', handleResize);
    // Call once initially
    handleResize(); 
    return () => window.removeEventListener('resize', handleResize);
  }, []);


  return (
    <div className="flex h-screen bg-[#161B22] text-gray-200">
      <Sidebar isSidebarOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
      <div
        className={`flex-1 flex flex-col overflow-hidden transition-all duration-300 ease-in-out ${
          isSidebarOpen ? 'md:ml-64' : 'md:ml-20' // Adjust margin based on desktop sidebar state
        } ${isSidebarOpen && window.innerWidth <=768 ? 'ml-0' : ''}`} // Full width content when mobile sidebar is open (it overlays)
      >
        <TopBar onSidebarToggle={toggleSidebar} />
        <main className="flex-1 overflow-x-hidden overflow-y-auto p-6">
          <Outlet /> {/* Page content will be rendered here */}
        </main>
      </div>
       {/* Mobile overlay for sidebar */}
      {isSidebarOpen && window.innerWidth <= 768 && (
        <div 
          className="fixed inset-0 z-20 bg-black bg-opacity-50 md:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
    </div>
  );
};

import React from 'react';

interface IconBaseProps {
  children: React.ReactNode;
  className?: string;
  size?: number;
  viewBox?: string;
}

export const IconBase: React.FC<IconBaseProps> = ({ children, className = 'w-6 h-6', size = 24, viewBox = '0 0 24 24' }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox={viewBox}
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      {children}
    </svg>
  );
};
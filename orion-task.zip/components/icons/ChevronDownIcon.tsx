
import React from 'react';
import { IconBase } from './IconBase';

export const ChevronDownIcon: React.FC<{ className?: string }> = ({ className }) => (
  <IconBase className={className}>
    <polyline points="6 9 12 15 18 9"></polyline>
  </IconBase>
);
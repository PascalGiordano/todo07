
import React from 'react';
import { IconBase } from './IconBase';

export const NotesIcon: React.FC<{ className?: string }> = ({ className }) => (
  <IconBase className={className}>
    <path d="M13.5 2H6.5C5.39543 2 4.5 2.89543 4.5 4V20C4.5 21.1046 5.39543 22 6.5 22H17.5C18.6046 22 19.5 21.1046 19.5 20V9L13.5 2Z"></path>
    <path d="M13 2V9H20"></path>
  </IconBase>
);

import React from 'react';
import { IconBase } from './IconBase';

export const CategoryIcon: React.FC<{ className?: string }> = ({ className }) => (
  <IconBase className={className}>
    <path d="M2 17l10-10 10 10M2 7l10 10 10-10"></path>
    <path d="M12 2L2 7l10 5 10-5-10-5z"></path> {/* Simplified representation of layered tags or categories */}
    <path d="M2 12l10 5 10-5"></path>
  </IconBase>
);

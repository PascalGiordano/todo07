
import React from 'react';
import { IconBase } from './IconBase';

export const ChevronRightIcon: React.FC<{ className?: string }> = ({ className }) => (
  <IconBase className={className}>
    <polyline points="9 18 15 12 9 6"></polyline>
  </IconBase>
);

import React from 'react';
import { IconBase } from './IconBase';

export const GripVerticalIcon: React.FC<{ className?: string }> = ({ className }) => (
  <IconBase className={className} viewBox="0 0 24 24">
    <circle cx="9" cy="12" r="1"></circle>
    <circle cx="9" cy="5" r="1"></circle>
    <circle cx="9" cy="19" r="1"></circle>
    <circle cx="15" cy="12" r="1"></circle>
    <circle cx="15" cy="5" r="1"></circle>
    <circle cx="15" cy="19" r="1"></circle>
  </IconBase>
);

import React, { useState, useEffect } from 'react';
import { Modal } from './ui/Modal';
import { Input } from './ui/Input'; // Textarea removed
import { RichTextEditor } from './ui/RichTextEditor'; // Import RichTextEditor
import { Button } from './ui/Button';
import { Project, ProjectStatus, EditProjectModalProps } from '../types';
import { COLORS, MOCK_USERS } from '../constants';

export const EditProjectModal: React.FC<EditProjectModalProps> = ({ isOpen, onClose, project, onSave }) => {
  const [editedProject, setEditedProject] = useState<Project>(project);

  useEffect(() => {
    setEditedProject(project);
  }, [project]);

  const handleInputChange = (field: keyof Project, value: any) => {
    setEditedProject(prev => ({ ...prev, [field]: value }));
  };

  const handleDescriptionChange = (htmlContent: string) => {
    setEditedProject(prev => ({ ...prev, description: htmlContent }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(editedProject);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Edit Project">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          label="Project Name"
          id="projectName"
          value={editedProject.projectName}
          onChange={(e) => handleInputChange('projectName', e.target.value)}
          required
        />
        <RichTextEditor
          label="Description"
          id="projectDescription"
          value={editedProject.description}
          onChange={handleDescriptionChange}
          placeholder="Enter project description..."
        />
        <div>
          <label htmlFor="status" className="block text-sm font-medium text-gray-300 mb-1">Status</label>
          <select
            id="status"
            value={editedProject.status}
            onChange={(e) => handleInputChange('status', e.target.value as ProjectStatus)}
            className={`w-full p-2 text-sm rounded-md border bg-[#161B22] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
          >
            {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="ownerId" className="block text-sm font-medium text-gray-300 mb-1">Owner</label>
          <select
            id="ownerId"
            value={editedProject.ownerId}
            onChange={(e) => handleInputChange('ownerId', e.target.value)}
            className={`w-full p-2 text-sm rounded-md border bg-[#161B22] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
          >
            {MOCK_USERS.map(u => <option key={u.userId} value={u.userId}>{u.firstName} {u.lastName}</option>)}
          </select>
        </div>
        <Input
          label="Start Date"
          id="startDate"
          type="date"
          value={editedProject.startDate ? editedProject.startDate.split('T')[0] : ''}
          onChange={(e) => handleInputChange('startDate', e.target.value ? new Date(e.target.value).toISOString() : '')}
        />
        <Input
          label="End Date"
          id="endDate"
          type="date"
          value={editedProject.endDate ? editedProject.endDate.split('T')[0] : ''}
          onChange={(e) => handleInputChange('endDate', e.target.value ? new Date(e.target.value).toISOString() : '')}
        />
        <div className="flex items-center">
            <input 
                type="checkbox" 
                id="editIsFavorite"
                checked={editedProject.isFavorite}
                onChange={(e) => handleInputChange('isFavorite', e.target.checked)}
                className={`h-4 w-4 text-[${COLORS.primary}] border-gray-600 rounded focus:ring-[${COLORS.primary}]`}
            />
            <label htmlFor="editIsFavorite" className="ml-2 text-sm text-gray-300">Mark as favorite</label>
        </div>
        <div className="flex justify-end space-x-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="primary">Save Changes</Button>
        </div>
      </form>
    </Modal>
  );
};

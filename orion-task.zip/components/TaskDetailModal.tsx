
import React, { useState, useEffect, useRef } from 'react';
import { Task, User, Subtask, Checklist, ChecklistItem, Comment, Attachment, Tag as TagType, TaskPriority, TaskStatus, Category } from '../types';
import { Modal } from './ui/Modal';
import { Avatar } from './ui/Avatar';
import { Tag } from './ui/Tag';
import { Input } from './ui/Input';
import { RichTextEditor } from './ui/RichTextEditor';
import { Textarea } from './ui/Input';
import { Button } from './ui/Button';
import { MOCK_USERS, MOCK_TAGS, PRIORITY_COLORS, STATUS_COLORS, COLORS, MOCK_PROJECTS, MOCK_CATEGORIES } from '../constants';
import { formatDate, formatDateTime } from '../utils/helpers';
import { PlusIcon } from './icons/PlusIcon';
import { PaperClipIcon } from '@heroicons/react/24/outline';
import { TrashIcon } from './icons/TrashIcon'; // Re-using our TrashIcon

const CheckCircleIcon: React.FC<{className?: string}> = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-5 h-5 text-green-500"}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const CircleIcon: React.FC<{className?: string}> = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-5 h-5 text-gray-400"}><path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const EditPencilIcon: React.FC<{className?: string}> = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-4 h-4"}><path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" /></svg>;


interface TaskDetailModalProps {
  task: Task | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateTask: (updatedTask: Task) => void;
}

type TabKey = 'details' | 'subtasks' | 'checklists' | 'attachments' | 'comments';

export const TaskDetailModal: React.FC<TaskDetailModalProps> = ({ task, isOpen, onClose, onUpdateTask }) => {
  const [activeTab, setActiveTab] = useState<TabKey>('details');
  const [editableTask, setEditableTask] = useState<Task | null>(task);
  const [newComment, setNewComment] = useState('');
  const [newSubtaskName, setNewSubtaskName] = useState('');

  // Checklist specific states
  const [newChecklistTitle, setNewChecklistTitle] = useState('');
  const [editingChecklistId, setEditingChecklistId] = useState<string | null>(null);
  const [editingChecklistTitle, setEditingChecklistTitle] = useState('');
  const [editingChecklistItemId, setEditingChecklistItemId] = useState<string | null>(null);
  const [editingChecklistItemName, setEditingChecklistItemName] = useState('');
  const [newChecklistItemName, setNewChecklistItemName] = useState<{ [key: string]: string }>({}); // Stores new item name per checklist

  const newChecklistItemInputRef = useRef<HTMLInputElement | null>(null);


  useEffect(() => {
    setEditableTask(task); 
    setActiveTab('details'); 
    // Reset checklist specific states when task changes
    setNewChecklistTitle('');
    setEditingChecklistId(null);
    setEditingChecklistTitle('');
    setNewChecklistItemName({});
    setEditingChecklistItemId(null);
    setEditingChecklistItemName('');
  }, [task]);

  if (!isOpen || !editableTask) return null;

  const assigneesDetails = editableTask.assignees.map(id => MOCK_USERS.find(u => u.userId === id)).filter(Boolean) as User[];
  const projectTags = MOCK_TAGS; 
  const projectCategories = MOCK_CATEGORIES;

  const handleInputChange = <K extends keyof Task>(field: K, value: Task[K]) => {
    setEditableTask(prev => prev ? { ...prev, [field]: value } : null);
  };

  const handleDescriptionChange = (htmlContent: string) => {
    setEditableTask(prev => prev ? { ...prev, description: htmlContent } : null);
  };
  
  const handleSave = () => {
    if (editableTask) {
      onUpdateTask(editableTask);
    }
  };

  // Subtask Functions
  const addSubtask = () => {
    if (newSubtaskName.trim() && editableTask) {
        const subtask: Subtask = {
            subtaskId: `sub-${Date.now()}`,
            subtaskName: newSubtaskName.trim(),
            isCompleted: false,
        };
        handleInputChange('subtasks', [...editableTask.subtasks, subtask]);
        setNewSubtaskName('');
    }
  };
  const toggleSubtask = (subtaskId: string) => {
    if (editableTask) {
        const updatedSubtasks = editableTask.subtasks.map(st => 
            st.subtaskId === subtaskId ? { ...st, isCompleted: !st.isCompleted } : st
        );
        handleInputChange('subtasks', updatedSubtasks);
    }
  };
  const deleteSubtask = (subtaskId: string) => {
    if (editableTask && window.confirm('Are you sure you want to delete this subtask?')) {
        const updatedSubtasks = editableTask.subtasks.filter(st => st.subtaskId !== subtaskId);
        handleInputChange('subtasks', updatedSubtasks);
    }
  };

  // Checklist Functions
  const handleAddChecklist = () => {
    if (newChecklistTitle.trim() && editableTask) {
      const newCl: Checklist = {
        checklistId: `cl-${Date.now()}`,
        title: newChecklistTitle.trim(),
        items: [],
      };
      setEditableTask(prev => prev ? { ...prev, checklists: [...prev.checklists, newCl] } : null);
      setNewChecklistTitle('');
    }
  };

  const handleDeleteChecklist = (checklistId: string) => {
    if (editableTask && window.confirm('Are you sure you want to delete this entire checklist?')) {
      setEditableTask(prev => prev ? { ...prev, checklists: prev.checklists.filter(cl => cl.checklistId !== checklistId) } : null);
    }
  };

  const handleStartEditChecklistTitle = (checklist: Checklist) => {
    setEditingChecklistId(checklist.checklistId);
    setEditingChecklistTitle(checklist.title);
  };

  const handleSaveChecklistTitle = (checklistId: string) => {
    if (editableTask) {
      setEditableTask(prev => prev ? {
        ...prev,
        checklists: prev.checklists.map(cl => cl.checklistId === checklistId ? { ...cl, title: editingChecklistTitle.trim() } : cl)
      } : null);
      setEditingChecklistId(null);
      setEditingChecklistTitle('');
    }
  };
  
  const handleAddChecklistItem = (checklistId: string) => {
    const itemName = newChecklistItemName[checklistId]?.trim();
    if (itemName && editableTask) {
      const newItem: ChecklistItem = {
        itemId: `cli-${Date.now()}`,
        itemName: itemName,
        isCompleted: false,
      };
      setEditableTask(prev => prev ? {
        ...prev,
        checklists: prev.checklists.map(cl => cl.checklistId === checklistId ? { ...cl, items: [...cl.items, newItem] } : cl)
      } : null);
      setNewChecklistItemName(prev => ({ ...prev, [checklistId]: '' }));
      if (newChecklistItemInputRef.current) {
        newChecklistItemInputRef.current.focus();
      }
    }
  };

  const handleToggleChecklistItem = (checklistId: string, itemId: string) => {
    if (editableTask) {
      setEditableTask(prev => prev ? {
        ...prev,
        checklists: prev.checklists.map(cl => cl.checklistId === checklistId ? {
          ...cl,
          items: cl.items.map(item => item.itemId === itemId ? { ...item, isCompleted: !item.isCompleted } : item)
        } : cl)
      } : null);
    }
  };

  const handleDeleteChecklistItem = (checklistId: string, itemId: string) => {
     if (editableTask && window.confirm('Delete this checklist item?')) {
        setEditableTask(prev => prev ? {
            ...prev,
            checklists: prev.checklists.map(cl => cl.checklistId === checklistId ? {
            ...cl,
            items: cl.items.filter(item => item.itemId !== itemId)
            } : cl)
        } : null);
    }
  };

  const handleStartEditChecklistItemName = (item: ChecklistItem) => {
    setEditingChecklistItemId(item.itemId);
    setEditingChecklistItemName(item.itemName);
  };

  const handleSaveChecklistItemName = (checklistId: string, itemId: string) => {
    if (editableTask) {
      setEditableTask(prev => prev ? {
        ...prev,
        checklists: prev.checklists.map(cl => cl.checklistId === checklistId ? {
          ...cl,
          items: cl.items.map(item => item.itemId === itemId ? { ...item, itemName: editingChecklistItemName.trim() } : item)
        } : cl)
      } : null);
      setEditingChecklistItemId(null);
      setEditingChecklistItemName('');
    }
  };


  // Comment Functions
  const addComment = () => {
    if (newComment.trim() && editableTask) {
      const comment: Comment = {
        commentId: `cmt-${Date.now()}`,
        userId: MOCK_USERS[0].userId, 
        content: newComment.trim(),
        createdAt: new Date().toISOString(),
      };
      handleInputChange('comments', [...editableTask.comments, comment]);
      setNewComment('');
    }
  };


  const TabButton: React.FC<{tabKey: TabKey; label: string; count?: number}> = ({tabKey, label, count}) => (
    <button
        onClick={() => setActiveTab(tabKey)}
        className={`px-3 py-2 text-sm font-medium transition-colors ${
        activeTab === tabKey
            ? `text-[${COLORS.primary}] border-b-2 border-[${COLORS.primary}]`
            : `text-gray-400 hover:text-gray-200 border-b-2 border-transparent`
        }`}
    >
        {label} {typeof count !== 'undefined' && `(${count})`}
    </button>
  );

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={editableTask.title} size="xl">
      <div className="flex flex-col md:flex-row md:space-x-6">
        <div className="flex-grow md:w-2/3">
          <div className="mb-4 border-b border-gray-700">
            <nav className="-mb-px flex space-x-1 sm:space-x-2 flex-wrap" aria-label="Tabs">
              <TabButton tabKey="details" label="Details" />
              <TabButton tabKey="subtasks" label="Subtasks" count={editableTask.subtasks.length} />
              <TabButton tabKey="checklists" label="Checklists" count={editableTask.checklists.length} />
              <TabButton tabKey="attachments" label="Attachments" count={editableTask.attachments.length} />
              <TabButton tabKey="comments" label="Comments" count={editableTask.comments.length} />
            </nav>
          </div>

          {activeTab === 'details' && (
            <div className="space-y-4">
              <RichTextEditor
                label="Description"
                id={`task-desc-${editableTask.taskId}`}
                value={editableTask.description}
                onChange={handleDescriptionChange}
                placeholder="Add a detailed description..."
              />
              <Button onClick={handleSave} variant="primary" size="sm">Save Changes</Button>
            </div>
          )}

          {activeTab === 'subtasks' && (
             <div className="space-y-3">
              <div className="flex space-x-2 mb-3">
                <Input 
                    value={newSubtaskName} 
                    onChange={(e) => setNewSubtaskName(e.target.value)} 
                    placeholder="New subtask name" 
                    wrapperClassName="flex-grow !mb-0"
                    className="text-sm"
                />
                <Button onClick={addSubtask} variant="primary" size="sm" disabled={!newSubtaskName.trim()}>Add</Button>
              </div>
              {editableTask.subtasks.length === 0 && <p className="text-gray-400 text-sm">No subtasks yet.</p>}
              {editableTask.subtasks.map((subtask) => (
                <div key={subtask.subtaskId} className="flex items-center justify-between p-2 bg-[#0D1117] rounded-md hover:bg-opacity-80">
                  <div className="flex items-center">
                    <button onClick={() => toggleSubtask(subtask.subtaskId)} className="mr-2 p-1">
                      {subtask.isCompleted ? <CheckCircleIcon /> : <CircleIcon />}
                    </button>
                    <span className={`text-sm ${subtask.isCompleted ? 'line-through text-gray-500' : 'text-gray-200'}`}>
                      {subtask.subtaskName}
                    </span>
                  </div>
                  <button onClick={() => deleteSubtask(subtask.subtaskId)} className="p-1">
                    <TrashIcon className="w-4 h-4 text-gray-500 hover:text-red-500"/>
                  </button>
                </div>
              ))}
            </div>
          )}
          
          {activeTab === 'checklists' && (
            <div className="space-y-4">
              <div className="flex space-x-2 mb-4">
                <Input
                  value={newChecklistTitle}
                  onChange={(e) => setNewChecklistTitle(e.target.value)}
                  placeholder="New checklist title"
                  wrapperClassName="flex-grow !mb-0"
                  className="text-sm"
                />
                <Button onClick={handleAddChecklist} variant="primary" size="sm" disabled={!newChecklistTitle.trim()}>
                  Add Checklist
                </Button>
              </div>
              {editableTask.checklists.length === 0 && <p className="text-gray-400 text-sm">No checklists yet.</p>}
              {editableTask.checklists.map(cl => {
                const completedItems = cl.items.filter(item => item.isCompleted).length;
                const totalItems = cl.items.length;
                const progress = totalItems > 0 ? (completedItems / totalItems) * 100 : 0;
                return (
                  <div key={cl.checklistId} className="p-3 bg-[#0D1117] rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      {editingChecklistId === cl.checklistId ? (
                        <div className="flex-grow flex items-center">
                          <Input 
                            value={editingChecklistTitle}
                            onChange={(e) => setEditingChecklistTitle(e.target.value)}
                            className="text-sm !py-1 mr-2"
                            wrapperClassName="flex-grow !mb-0"
                            autoFocus
                            onBlur={() => handleSaveChecklistTitle(cl.checklistId)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSaveChecklistTitle(cl.checklistId)}
                          />
                           <Button size="sm" variant="primary" onClick={() => handleSaveChecklistTitle(cl.checklistId)}>Save</Button>
                        </div>
                      ) : (
                        <h4 className="text-md font-semibold text-gray-200 flex-grow cursor-text" onClick={() => handleStartEditChecklistTitle(cl)}>
                          {cl.title}
                        </h4>
                      )}
                      <div className="flex items-center space-x-2">
                         {!editingChecklistId && <Button variant="ghost" size="sm" onClick={() => handleStartEditChecklistTitle(cl)} className="!p-1"><EditPencilIcon className="w-4 h-4 text-gray-400 hover:text-white" /></Button> }
                         <Button variant="ghost" size="sm" onClick={() => handleDeleteChecklist(cl.checklistId)} className="!p-1"><TrashIcon className="w-4 h-4 text-gray-400 hover:text-red-500" /></Button>
                      </div>
                    </div>
                    
                    {/* Progress Bar */}
                    {totalItems > 0 && (
                        <div className="mb-2">
                            <div className="flex justify-between text-xs text-gray-400 mb-0.5">
                                <span>Progress</span>
                                <span>{completedItems}/{totalItems}</span>
                            </div>
                            <div className="w-full bg-gray-600 rounded-full h-1.5">
                                <div className={`bg-[${COLORS.primary}] h-1.5 rounded-full`} style={{ width: `${progress}%` }}></div>
                            </div>
                        </div>
                    )}

                    <div className="space-y-1.5 pl-1 max-h-48 overflow-y-auto pr-1">
                      {cl.items.map(item => (
                        <div key={item.itemId} className="flex items-center justify-between p-1.5 bg-[#161B22] rounded hover:bg-opacity-80 text-sm">
                          <div className="flex items-center flex-grow">
                            <button onClick={() => handleToggleChecklistItem(cl.checklistId, item.itemId)} className="mr-2 p-0.5">
                              {item.isCompleted ? <CheckCircleIcon className="w-4 h-4"/> : <CircleIcon className="w-4 h-4"/>}
                            </button>
                            {editingChecklistItemId === item.itemId ? (
                               <Input 
                                value={editingChecklistItemName}
                                onChange={(e) => setEditingChecklistItemName(e.target.value)}
                                className="text-sm !py-0.5 flex-grow"
                                wrapperClassName="flex-grow !mb-0"
                                autoFocus
                                onBlur={() => handleSaveChecklistItemName(cl.checklistId, item.itemId)}
                                onKeyDown={(e) => e.key === 'Enter' && handleSaveChecklistItemName(cl.checklistId, item.itemId)}
                              />
                            ) : (
                                <span 
                                    className={`cursor-text ${item.isCompleted ? 'line-through text-gray-500' : 'text-gray-300'} flex-grow`}
                                    onClick={() => handleStartEditChecklistItemName(item)}
                                >
                                {item.itemName}
                                </span>
                            )}
                          </div>
                           <div className="flex items-center space-x-1 ml-2">
                                {!editingChecklistItemId && <Button variant="ghost" size="sm" onClick={() => handleStartEditChecklistItemName(item)} className="!p-0.5"><EditPencilIcon className="w-3.5 h-3.5 text-gray-500 hover:text-white" /></Button> }
                                <Button variant="ghost" size="sm" onClick={() => handleDeleteChecklistItem(cl.checklistId, item.itemId)} className="!p-0.5"><TrashIcon className="w-3.5 h-3.5 text-gray-500 hover:text-red-500" /></Button>
                           </div>
                        </div>
                      ))}
                    </div>
                    <div className="flex space-x-2 mt-2.5">
                      <Input
                        ref={newChecklistItemInputRef}
                        value={newChecklistItemName[cl.checklistId] || ''}
                        onChange={(e) => setNewChecklistItemName(prev => ({ ...prev, [cl.checklistId]: e.target.value }))}
                        placeholder="New item name"
                        wrapperClassName="flex-grow !mb-0"
                        className="text-sm !py-1"
                        onKeyDown={(e) => e.key === 'Enter' && handleAddChecklistItem(cl.checklistId)}
                      />
                      <Button onClick={() => handleAddChecklistItem(cl.checklistId)} variant="secondary" size="sm" disabled={!newChecklistItemName[cl.checklistId]?.trim()}>Add Item</Button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}


          {activeTab === 'attachments' && (
            <div className="space-y-3">
              <Button variant="outline" size="sm" leftIcon={<PaperClipIcon className="w-4 h-4" />}>
                Upload File
              </Button>
              {editableTask.attachments.length === 0 && <p className="text-gray-400 text-sm">No attachments yet.</p>}
              {editableTask.attachments.map((att, index) => (
                <div key={index} className="flex items-center justify-between p-2.5 bg-[#0D1117] rounded-md text-sm">
                  <a href={att.url} target="_blank" rel="noopener noreferrer" className={`text-[${COLORS.primary}] hover:underline truncate`}>
                    {att.fileName}
                  </a>
                  <span className="text-xs text-gray-500">{formatDateTime(att.uploadedAt)}</span>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'comments' && (
            <div className="space-y-4">
              <div className="mt-2">
                <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add a comment..."
                    rows={3}
                    className="text-sm"
                />
                <Button onClick={addComment} variant="primary" size="sm" className="mt-2" disabled={!newComment.trim()}>
                    Post Comment
                </Button>
              </div>
              <div className="max-h-60 overflow-y-auto space-y-3 pr-2">
                {editableTask.comments.length === 0 && <p className="text-gray-400 text-sm">No comments yet.</p>}
                {editableTask.comments.slice().reverse().map((comment) => {
                  const commenter = MOCK_USERS.find(u => u.userId === comment.userId);
                  return (
                    <div key={comment.commentId} className="flex items-start space-x-3 p-3 bg-[#0D1117] rounded-md">
                      <Avatar user={commenter} size="sm" />
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-semibold text-gray-100">{commenter?.firstName} {commenter?.lastName}</span>
                          <span className="text-xs text-gray-500">{formatDateTime(comment.createdAt)}</span>
                        </div>
                        <p className="text-sm text-gray-300 whitespace-pre-wrap">{comment.content}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="md:w-1/3 mt-6 md:mt-0 space-y-5 p-4 bg-[#0D1117] rounded-lg h-fit sticky top-20">
          <div>
            <label className="block text-xs text-gray-400 mb-1">Status</label>
            <select
              value={editableTask.status}
              onChange={(e) => handleInputChange('status', e.target.value as TaskStatus)}
              className={`w-full p-2 text-sm rounded-md border bg-[#161B22] border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
              style={{ color: STATUS_COLORS[editableTask.status], fontWeight: 500 }}
            >
              {Object.values(TaskStatus).map(s => <option key={s} value={s} style={{color: STATUS_COLORS[s], backgroundColor: COLORS.darkBgLighter}}>{s}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-xs text-gray-400 mb-1">Priority</label>
            <select
              value={editableTask.priority}
              onChange={(e) => handleInputChange('priority', e.target.value as TaskPriority)}
              className={`w-full p-2 text-sm rounded-md border bg-[#161B22] border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
              style={{ color: PRIORITY_COLORS[editableTask.priority], fontWeight: 500 }}
            >
              {Object.values(TaskPriority).map(p => <option key={p} value={p} style={{color: PRIORITY_COLORS[p], backgroundColor: COLORS.darkBgLighter}}>{p}</option>)}
            </select>
          </div>
           <div>
            <label className="block text-xs text-gray-400 mb-1">Category</label>
            <select
              value={editableTask.categoryId || ''}
              onChange={(e) => handleInputChange('categoryId', e.target.value || undefined)}
              className={`w-full p-2 text-sm rounded-md border bg-[#161B22] border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
              style={{ color: projectCategories.find(c=>c.categoryId === editableTask.categoryId)?.color || COLORS.darkText, fontWeight: 500 }}
            >
              <option value="" style={{color: COLORS.darkTextSecondary, backgroundColor: COLORS.darkBgLighter}}>No Category</option>
              {projectCategories.map(cat => <option key={cat.categoryId} value={cat.categoryId} style={{color: cat.color, backgroundColor: COLORS.darkBgLighter}}>{cat.categoryName}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Due Date</label>
            <Input
              type="date"
              value={editableTask.dueDate ? editableTask.dueDate.split('T')[0] : ''}
              onChange={(e) => handleInputChange('dueDate', e.target.value ? new Date(e.target.value).toISOString() : undefined)}
              className="text-sm"
              wrapperClassName="!mb-0"
            />
          </div>

          <div>
            <label className="block text-xs text-gray-400 mb-1">Assignees</label>
            <div className="flex flex-wrap gap-1">
              {assigneesDetails.map(user => (
                <div key={user.userId} className="flex items-center bg-gray-700 p-1 rounded">
                  <Avatar user={user} size="sm" />
                  <span className="text-xs ml-1.5 mr-1 text-gray-200">{user.firstName}</span>
                </div>
              ))}
            </div>
            <select multiple={false}
                className="mt-2 w-full p-2 text-sm rounded-md border bg-[#161B22] border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]"
                onChange={(e) => {
                    const userId = e.target.value;
                    if (userId && !editableTask.assignees.includes(userId)) {
                        handleInputChange('assignees', [...editableTask.assignees, userId]);
                    }
                }}
                 value={""} 
            >
                <option value="">Add assignee...</option>
                {MOCK_USERS.filter(u => !editableTask.assignees.includes(u.userId)).map(user => (
                    <option key={user.userId} value={user.userId}>{user.firstName} {user.lastName}</option>
                ))}
            </select>
          </div>

          <div>
            <label className="block text-xs text-gray-400 mb-1">Tags</label>
            <div className="flex flex-wrap gap-1.5">
              {editableTask.tags.map(tagId => <Tag key={tagId} tagId={tagId} />)}
            </div>
            <select
                className="mt-2 w-full p-2 text-sm rounded-md border bg-[#161B22] border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]"
                onChange={(e) => {
                    const tagId = e.target.value;
                    if (tagId && !editableTask.tags.includes(tagId)) {
                        handleInputChange('tags', [...editableTask.tags, tagId]);
                    }
                }}
                value={""}
            >
                <option value="">Add tag...</option>
                {projectTags.filter(t => !editableTask.tags.includes(t.tagId)).map(tag => (
                    <option key={tag.tagId} value={tag.tagId}>{tag.tagName}</option>
                ))}
            </select>
          </div>
          
          <div className="text-xs text-gray-500 mt-4">
            <p>Created: {formatDateTime(editableTask.createdAt)}</p>
            <p>Project: {MOCK_PROJECTS.find(p => p.projectId === editableTask.projectId)?.projectName || 'N/A'}</p>
          </div>
        </div>
      </div>
    </Modal>
  );
};

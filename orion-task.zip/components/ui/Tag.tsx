
import React from 'react';
import { Tag as TagType } from '../../types';
import { MOCK_TAGS } from '../../constants'; // To get color if only ID is passed

interface TagProps {
  tagId: string;
  tagName?: string; // Optional, can be fetched if only ID is provided
  color?: string; // Optional, can be fetched
  size?: 'sm' | 'md';
}

export const Tag: React.FC<TagProps> = ({ tagId, tagName, color, size = 'sm' }) => {
  const tagInfo = MOCK_TAGS.find(t => t.tagId === tagId);
  const displayColor = color || tagInfo?.color || '#718096'; // Default gray
  const displayName = tagName || tagInfo?.tagName || 'Unknown Tag';

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-sm',
  };

  // Function to determine if a color is light or dark for text contrast
  const getTextColor = (backgroundColor: string): string => {
    const hex = backgroundColor.replace('#', '');
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness > 155 ? '#000000' : '#FFFFFF'; // Return black for light backgrounds, white for dark
  };
  
  const textColor = getTextColor(displayColor);

  return (
    <span
      className={`inline-block rounded-full font-medium ${sizeClasses[size]}`}
      style={{ backgroundColor: displayColor, color: textColor }}
    >
      {displayName}
    </span>
  );
};
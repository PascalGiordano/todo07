
import React from 'react';
import { COLORS } from '../../constants';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  wrapperClassName?: string;
}

// FIX: Wrap Input component with React.forwardRef to allow passing refs
export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, id, error, className = '', wrapperClassName = '', ...props }, ref) => {
    const baseInputClasses = `w-full px-3 py-2 bg-[#0D1117] border border-gray-600 rounded-md text-[${COLORS.darkText}] placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}] transition-colors`;
    
    return (
      <div className={`mb-4 ${wrapperClassName}`}>
        {label && (
          <label htmlFor={id} className={`block text-sm font-medium text-[${COLORS.darkTextSecondary}] mb-1`}>
            {label}
          </label>
        )}
        <input
          id={id}
          // FIX: Assign the forwarded ref to the input element
          ref={ref}
          className={`${baseInputClasses} ${error ? 'border-red-500' : ''} ${className}`}
          {...props}
        />
        {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
      </div>
    );
  }
);
// FIX: Add display name for better debugging with React DevTools
Input.displayName = 'Input';

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  wrapperClassName?: string;
}

// FIX: Wrap Textarea component with React.forwardRef for consistency and future use with refs
export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, id, error, className = '', wrapperClassName = '', ...props }, ref) => {
    const baseTextareaClasses = `w-full px-3 py-2 bg-[#0D1117] border border-gray-600 rounded-md text-[${COLORS.darkText}] placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}] transition-colors`;

    return (
      <div className={`mb-4 ${wrapperClassName}`}>
        {label && (
          <label htmlFor={id} className={`block text-sm font-medium text-[${COLORS.darkTextSecondary}] mb-1`}>
            {label}
          </label>
        )}
        <textarea
          id={id}
          // FIX: Assign the forwarded ref to the textarea element
          ref={ref}
          className={`${baseTextareaClasses} ${error ? 'border-red-500' : ''} ${className}`}
          rows={4}
          {...props}
        />
        {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
      </div>
    );
  }
);
// FIX: Add display name for better debugging with React DevTools
Textarea.displayName = 'Textarea';

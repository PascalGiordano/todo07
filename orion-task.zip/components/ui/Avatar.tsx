
import React from 'react';
import { User } from '../../types';

interface AvatarProps {
  user?: User;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const Avatar: React.FC<AvatarProps> = ({ user, size = 'md', className }) => {
  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
  };

  if (!user) {
    return (
      <div
        className={`flex items-center justify-center rounded-full bg-gray-500 ${sizeClasses[size]} ${className}`}
        title="Unknown User"
      >
        <span className="font-semibold text-white">?</span>
      </div>
    );
  }

  return (
    <div
      className={`flex items-center justify-center rounded-full ${sizeClasses[size]} ${className}`}
      style={{ backgroundColor: user.avatarUrl ? 'transparent' : user.avatarBackgroundColor }}
      title={`${user.firstName} ${user.lastName}`}
    >
      {user.avatarUrl ? (
        <img src={user.avatarUrl} alt={`${user.firstName} ${user.lastName}`} className="rounded-full w-full h-full object-cover" />
      ) : (
        <span className="font-semibold text-white">{user.initials}</span>
      )}
    </div>
  );
};

import React from 'react';
import { COLORS } from '../../constants';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  actions?: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({ children, className = '', title, actions }) => {
  return (
    <div className={`bg-[${COLORS.darkBgLighter}] shadow-lg rounded-lg overflow-hidden ${className}`}>
      {(title || actions) && (
        <div className="p-4 border-b border-gray-700 flex justify-between items-center">
          {title && <h3 className="text-lg font-semibold text-[${COLORS.darkText}]">{title}</h3>}
          {actions && <div>{actions}</div>}
        </div>
      )}
      <div className="p-4">
        {children}
      </div>
    </div>
  );
};

import React, { Fragment } from 'react';
import { XIcon } from '../icons/XIcon';
import { COLORS } from '../../constants';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
}

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, size = 'md' }) => {
  if (!isOpen) return null;

  const sizeClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
    full: 'max-w-full h-full',
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-75 transition-opacity duration-300"
      onClick={onClose}
    >
      <div
        className={`bg-[${COLORS.darkBgLighter}] text-[${COLORS.darkText}] rounded-lg shadow-xl overflow-y-auto max-h-[90vh] flex flex-col ${sizeClasses[size]} w-full transform transition-all duration-300 scale-95 opacity-0 animate-modal-appear`}
        onClick={(e) => e.stopPropagation()}
        style={{ animationFillMode: 'forwards' }} // Keep final state of animation
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-700 sticky top-0 bg-[${COLORS.darkBgLighter}] z-10">
          {title && <h2 className="text-xl font-semibold">{title}</h2>}
          <button
            onClick={onClose}
            className={`text-gray-400 hover:text-white transition-colors p-1 rounded-full hover:bg-[${COLORS.primary}] hover:bg-opacity-30`}
            aria-label="Close modal"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6 flex-grow overflow-y-auto">
          {children}
        </div>
      </div>
      <style>{`
        @keyframes modal-appear {
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
        .animate-modal-appear {
          animation-name: modal-appear;
          animation-duration: 0.3s;
          animation-timing-function: ease-out;
        }
      `}</style>
    </div>
  );
};
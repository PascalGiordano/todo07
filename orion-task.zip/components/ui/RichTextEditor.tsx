
import React, { useRef, useEffect, FormEvent } from 'react';
import { RichTextEditorProps } from '../../types';
import { COLORS } from '../../constants';
import { Button } from './Button'; // Reusing Button for toolbar items

// Simple icons for toolbar, replace with proper SVG icons if available
const BoldIcon = () => <b>B</b>;
const ItalicIcon = () => <i>I</i>;
const UnderlineIcon = () => <u>U</u>;
const ListOlIcon = () => <>1.</>;
const ListUlIcon = () => <>•</>;


export const RichTextEditor: React.FC<RichTextEditorProps> = ({
  value,
  onChange,
  placeholder,
  className = '',
  label,
  id,
  wrapperClassName = '',
}) => {
  const editorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== value) {
      editorRef.current.innerHTML = value;
    }
  }, [value]);

  const handleInput = (e: FormEvent<HTMLDivElement>) => {
    onChange(e.currentTarget.innerHTML);
  };

  const execCommand = (command: string, valueArg?: string) => {
    document.execCommand(command, false, valueArg);
    if (editorRef.current) {
      editorRef.current.focus(); // Keep focus on editor
      onChange(editorRef.current.innerHTML); // Ensure state updates after command
    }
  };
  
  const toolbarButtons = [
    { cmd: 'bold', icon: <BoldIcon />, title: 'Bold' },
    { cmd: 'italic', icon: <ItalicIcon />, title: 'Italic' },
    { cmd: 'underline', icon: <UnderlineIcon />, title: 'Underline' },
    { cmd: 'insertOrderedList', icon: <ListOlIcon />, title: 'Ordered List' },
    { cmd: 'insertUnorderedList', icon: <ListUlIcon />, title: 'Unordered List' },
  ];

  // Define specific classes for the content area, ensuring 'position: relative' for the ::before pseudo-element.
  // Removed placeholder-gray-500 as it's not applicable here and handled by custom CSS.
  // Borders and focus rings are handled by the parent div.
  const editorContentClasses = `w-full min-h-[120px] px-3 py-2 bg-[#0D1117] text-[${COLORS.darkText}] focus:outline-none overflow-y-auto relative rounded-b-md`;

  return (
    <div className={`mb-4 ${wrapperClassName}`}>
      {label && (
        <label htmlFor={id} className={`block text-sm font-medium text-[${COLORS.darkTextSecondary}] mb-1`}>
          {label}
        </label>
      )}
      <div className={`rounded-md border border-gray-600 focus-within:ring-2 focus-within:ring-[${COLORS.primary}] focus-within:border-[${COLORS.primary}]`}>
        <div className="flex items-center space-x-1 p-1.5 border-b border-gray-700 bg-[#1F2937] rounded-t-md">
          {toolbarButtons.map(btn => (
            <Button
              key={btn.cmd}
              variant="ghost"
              size="sm"
              onClick={() => execCommand(btn.cmd)}
              title={btn.title}
              className="!p-1.5 !text-gray-300 hover:!bg-gray-600"
            >
              {btn.icon}
            </Button>
          ))}
        </div>
        {/* FIX: Removed invalid 'placeholder' attribute from div. 
           Added 'data-placeholder' attribute to be used by CSS for placeholder text.
           CSS for '.content-editable-div::before' handles the actual placeholder display.
           Applied refactored 'editorContentClasses'.
        */}
        <div
          id={id}
          ref={editorRef}
          contentEditable
          onInput={handleInput}
          className={`${editorContentClasses} ${className} content-editable-div`}
          data-placeholder={placeholder}
          style={{ whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}
        />
      </div>
      {/* Style for the contentEditable div's placeholder */}
      <style>{`
        .content-editable-div[data-placeholder]:empty::before {
          content: attr(data-placeholder);
          color: ${COLORS.darkTextSecondary}; /* Using defined color constant for placeholder text */
          position: absolute;
          left: 0.75rem; /* Corresponds to px-3 */
          top: 0.5rem;  /* Corresponds to py-2 */
          pointer-events: none; /* Prevents interaction with the placeholder text */
          display: block;
        }
      `}</style>
    </div>
  );
};


import React, { useState } from 'react';
import { Modal } from './ui/Modal';
import { Input } from './ui/Input'; // Textarea removed, RichTextEditor will be used
import { RichTextEditor } from './ui/RichTextEditor'; // Import RichTextEditor
import { Button } from './ui/Button';
import { Task, TaskStatus, TaskPriority, CreateTaskModalProps, Category } from '../types';
import { COLORS, MOCK_USERS, MOCK_CATEGORIES } from '../constants';

export const CreateTaskModal: React.FC<CreateTaskModalProps> = ({ isOpen, onClose, projectId, onSave }) => {
  const [newTask, setNewTask] = useState<Partial<Task>>({
    title: '',
    description: '', // Initial description as empty string for RichTextEditor
    status: TaskStatus.ToDo,
    priority: TaskPriority.Medium,
    assignees: [],
    projectId: projectId,
    categoryId: MOCK_CATEGORIES.length > 0 ? MOCK_CATEGORIES[0].categoryId : undefined, // Default to first category or undefined
  });

  const handleInputChange = (field: keyof Task, value: any) => {
    setNewTask(prev => ({ ...prev, [field]: value }));
  };

  const handleDescriptionChange = (htmlContent: string) => {
    setNewTask(prev => ({ ...prev, description: htmlContent }));
  };
  
  const handleAssigneeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedUserIds = Array.from(e.target.selectedOptions, option => option.value);
    handleInputChange('assignees', selectedUserIds);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.title?.trim()) {
      alert("Task title is required.");
      return;
    }
    const taskToSave: Task = {
      ...newTask,
      taskId: `task-${Date.now()}`,
      title: newTask.title,
      description: newTask.description || '', // Ensure description is string
      status: newTask.status || TaskStatus.ToDo,
      priority: newTask.priority || TaskPriority.Medium,
      projectId: projectId,
      createdAt: new Date().toISOString(),
      attachments: [],
      subtasks: [],
      checklists: [],
      comments: [],
      tags: newTask.tags || [],
      categoryId: newTask.categoryId,
    } as Task;
    onSave(taskToSave);
    // Reset form:
    setNewTask({ 
        title: '', 
        description: '', 
        status: TaskStatus.ToDo, 
        priority: TaskPriority.Medium, 
        assignees: [], 
        projectId,
        categoryId: MOCK_CATEGORIES.length > 0 ? MOCK_CATEGORIES[0].categoryId : undefined,
    }); 
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Create New Task">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          label="Task Title"
          id="taskTitle"
          value={newTask.title || ''}
          onChange={(e) => handleInputChange('title', e.target.value)}
          required
        />
        <RichTextEditor
          label="Description (Optional)"
          id="taskDescription"
          value={newTask.description || ''}
          onChange={handleDescriptionChange}
          placeholder="Add a detailed description..."
        />
        <div>
          <label htmlFor="taskStatus" className="block text-sm font-medium text-gray-300 mb-1">Status</label>
          <select
            id="taskStatus"
            value={newTask.status}
            onChange={(e) => handleInputChange('status', e.target.value as TaskStatus)}
            className={`w-full p-2 text-sm rounded-md border bg-[#161B22] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
          >
            {Object.values(TaskStatus).map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="taskPriority" className="block text-sm font-medium text-gray-300 mb-1">Priority</label>
          <select
            id="taskPriority"
            value={newTask.priority}
            onChange={(e) => handleInputChange('priority', e.target.value as TaskPriority)}
            className={`w-full p-2 text-sm rounded-md border bg-[#161B22] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
          >
            {Object.values(TaskPriority).map(p => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="taskCategory" className="block text-sm font-medium text-gray-300 mb-1">Category</label>
          <select
            id="taskCategory"
            value={newTask.categoryId || ''}
            onChange={(e) => handleInputChange('categoryId', e.target.value)}
            className={`w-full p-2 text-sm rounded-md border bg-[#161B22] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
          >
            <option value="">Select a category</option>
            {MOCK_CATEGORIES.map(cat => <option key={cat.categoryId} value={cat.categoryId} style={{color: cat.color}}>{cat.categoryName}</option>)}
          </select>
        </div>
        <Input
          label="Due Date (Optional)"
          id="taskDueDate"
          type="date"
          value={newTask.dueDate ? newTask.dueDate.split('T')[0] : ''}
          onChange={(e) => handleInputChange('dueDate', e.target.value ? new Date(e.target.value).toISOString() : undefined)}
        />
        <div>
          <label htmlFor="taskAssignees" className="block text-sm font-medium text-gray-300 mb-1">Assignees (Optional)</label>
          <select
            id="taskAssignees"
            multiple
            value={newTask.assignees || []}
            onChange={handleAssigneeChange}
            className={`w-full p-2 text-sm rounded-md border bg-[#161B22] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}] h-24`}
          >
            {MOCK_USERS.map(u => <option key={u.userId} value={u.userId}>{u.firstName} {u.lastName}</option>)}
          </select>
           <p className="text-xs text-gray-400 mt-1">Hold Ctrl/Cmd to select multiple assignees.</p>
        </div>
        <div className="flex justify-end space-x-3 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="primary">Create Task</Button>
        </div>
      </form>
    </Modal>
  );
};

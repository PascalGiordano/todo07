
import React from 'react';
import { Task, User, Tag as TagType, TaskPriority, TaskStatus, Category, Checklist } from '../types';
import { MOCK_USERS, MOCK_TAGS, PRIORITY_COLORS, STATUS_COLORS, COLORS, MOCK_CATEGORIES } from '../constants';
import { Avatar } from './ui/Avatar';
import { Tag } from './ui/Tag';
import { formatDate, classNames } from '../utils/helpers';
import { TasksIcon } from './icons/TasksIcon'; 
import { CalendarIcon } from './icons/CalendarIcon';
import { GripVerticalIcon } from './icons/GripVerticalIcon';
import { ChecklistIcon } from './icons/ChecklistIcon'; // Import ChecklistIcon

interface TaskCardProps {
  task: Task;
  onClick?: (task: Task) => void;
  isDraggable?: boolean;
}

const getTextColorForBackground = (backgroundColor: string): string => {
    if (!backgroundColor || backgroundColor.length < 4) return '#FFFFFF';
    const hex = backgroundColor.replace('#', '');
    if (hex.length !== 3 && hex.length !== 6) return '#FFFFFF'; 
    
    let rStr, gStr, bStr;
    if (hex.length === 3) {
        rStr = hex.substring(0, 1) + hex.substring(0, 1);
        gStr = hex.substring(1, 2) + hex.substring(1, 2);
        bStr = hex.substring(2, 3) + hex.substring(2, 3);
    } else {
        rStr = hex.substring(0, 2);
        gStr = hex.substring(2, 4);
        bStr = hex.substring(4, 6);
    }
    
    const r = parseInt(rStr, 16);
    const g = parseInt(gStr, 16);
    const b = parseInt(bStr, 16);
    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness > 155 ? '#000000' : '#FFFFFF';
};

export const TaskCard: React.FC<TaskCardProps> = ({ task, onClick, isDraggable = false }) => {
  const assignees = task.assignees.map(id => MOCK_USERS.find(u => u.userId === id)).filter(Boolean) as User[];
  const category = MOCK_CATEGORIES.find(c => c.categoryId === task.categoryId);
  
  const priorityColor = PRIORITY_COLORS[task.priority] || COLORS.darkTextSecondary;

  const subtaskCount = task.subtasks.length;
  const completedSubtasks = task.subtasks.filter(st => st.isCompleted).length;
  const commentCount = task.comments.length;

  const totalChecklistItems = task.checklists.reduce((sum, cl) => sum + cl.items.length, 0);
  const completedChecklistItems = task.checklists.reduce((sum, cl) => sum + cl.items.filter(item => item.isCompleted).length, 0);

  return (
    <div
      className={classNames(
        `bg-[${COLORS.darkBgLighter}] rounded-lg shadow-md p-4 mb-4 border-l-4 hover:shadow-xl transition-shadow duration-200 group`,
        onClick ? 'cursor-pointer' : 'cursor-default'
      )}
      style={{ borderColor: priorityColor }}
      onClick={() => onClick?.(task)}
    >
      <div className="flex justify-between items-start">
        <h3 className={classNames("text-base font-semibold text-gray-100 mb-1 transition-colors", onClick && `group-hover:text-[${COLORS.primary}]`)}>
          {task.title}
        </h3>
        {isDraggable && <GripVerticalIcon className="w-5 h-5 text-gray-500 cursor-grab" />}
      </div>
      
      <p className="text-xs text-gray-400 mb-2 line-clamp-2">{task.description.replace(/<[^>]+>/g, '')}</p>

      <div className="mb-3 flex flex-wrap gap-1 items-center">
        {category && (
            <span
              className="px-2 py-0.5 text-xs rounded-full font-medium"
              style={{ backgroundColor: category.color, color: getTextColorForBackground(category.color) }}
            >
              {category.categoryName}
            </span>
        )}
        {task.tags.slice(0, category ? 2 : 3).map(tagId => (
          <Tag key={tagId} tagId={tagId} size="sm" />
        ))}
        {task.tags.length > (category ? 2 : 3) && <span className="text-xs text-gray-500 self-center">+{task.tags.length - (category ? 2 : 3)} more</span>}
      </div>


      <div className="flex justify-between items-center text-xs text-gray-400">
        <div className="flex items-center space-x-1">
          {task.dueDate && (
            <>
              <CalendarIcon className="w-3.5 h-3.5" />
              <span>{formatDate(task.dueDate)}</span>
            </>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {totalChecklistItems > 0 && (
            <span className="flex items-center" title={`${completedChecklistItems}/${totalChecklistItems} checklist items completed`}>
              <ChecklistIcon className="w-3.5 h-3.5 mr-0.5" /> {completedChecklistItems}/{totalChecklistItems}
            </span>
          )}
          {subtaskCount > 0 && (
            <span className="flex items-center" title={`${completedSubtasks}/${subtaskCount} subtasks completed`}>
              <TasksIcon className="w-3.5 h-3.5 mr-0.5" /> {completedSubtasks}/{subtaskCount}
            </span>
          )}
          {commentCount > 0 && (
            <span className="flex items-center" title={`${commentCount} comments`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="w-3.5 h-3.5 mr-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
              {commentCount}
            </span>
          )}
        </div>
      </div>

      {assignees.length > 0 && (
        <div className="mt-3 pt-3 border-t border-gray-700 flex items-center justify-between">
           <div className="flex -space-x-2 overflow-hidden">
            {assignees.slice(0,3).map(user => (
              <Avatar key={user.userId} user={user} size="sm" className={`border-2 border-[${COLORS.darkBgLighter}]`} />
            ))}
          </div>
          {assignees.length > 3 && <span className="text-xs text-gray-500 self-center">+{assignees.length - 3}</span>}
          <span 
            className={`px-2 py-0.5 text-xs rounded font-medium`} 
            style={{backgroundColor: STATUS_COLORS[task.status], color: getTextColorForBackground(STATUS_COLORS[task.status]) }}
          >
            {task.status}
          </span>
        </div>
      )}
       {!assignees.length && (
        <div className="mt-3 pt-3 border-t border-gray-700 flex items-center justify-end">
          <span 
            className={`px-2 py-0.5 text-xs rounded font-medium`} 
            style={{backgroundColor: STATUS_COLORS[task.status], color: getTextColorForBackground(STATUS_COLORS[task.status]) }}
          >
            {task.status}
          </span>
        </div>
      )}
    </div>
  );
};

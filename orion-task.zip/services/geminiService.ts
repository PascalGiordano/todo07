
// FIX: Import GoogleGenAI and GenerateContentResponse correctly.
// FIX: Remove GenerateContentParameters and GenerateContentResult as they are deprecated or incorrect.
import { GoogleGenAI, GenerateContentResponse, Part } from "@google/genai";
import { GEMINI_API_KEY } from '../constants';
import { AITaskSuggestion, Task, TaskPriority, GroundingChunk } from "../types";

const TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';

let ai: GoogleGenAI | null = null;

const getAiClient = (): GoogleGenAI | null => {
  if (!GEMINI_API_KEY) {
    console.error("Gemini API Key is not configured.");
    // alert("Gemini API Key is not configured. Please set the API_KEY environment variable.");
    return null;
  }
  if (!ai) {
    // FIX: Ensure apiKey is passed as a named parameter.
    ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
  }
  return ai;
};

export const parseTaskFromNaturalLanguage = async (prompt: string): Promise<Partial<Task> | null> => {
  const client = getAiClient();
  if (!client) return null;

  const systemInstruction = `You are an intelligent task creation assistant.
Parse the user's natural language input and convert it into a structured task object.
The task object should have 'title' (string), 'description' (string, optional), 'dueDate' (ISO8601 string, optional, if date/time is mentioned, assume current year if not specified), and 'priority' (Low, Medium, High, Urgent, optional).
If a date is "today", "tomorrow", "next Monday", etc., calculate the actual date.
Respond ONLY with a JSON object. Example:
User: "Schedule a meeting with the client tomorrow at 3pm about the new proposal"
Assistant: {"title": "Meeting with client about new proposal", "dueDate": "YYYY-MM-DDTHH:MM:SS.000Z", "priority": "Medium"}
User: "Finish the report by Friday high priority"
Assistant: {"title": "Finish the report", "dueDate": "YYYY-MM-DDTHH:MM:SS.000Z", "priority": "High"}
`;

  try {
    // FIX: Use client.models.generateContent
    const result: GenerateContentResponse = await client.models.generateContent({
      model: TEXT_MODEL,
      // FIX: contents should be an array of Content objects, or a single Content object.
      // For simple text prompt, it's `{ parts: [{ text: prompt }] }` wrapped in contents array if using roles.
      // Or more simply `contents: prompt` if no roles or multi-parts are needed directly in system prompt.
      // Given systemInstruction is in config, direct prompt is fine.
      // However, the existing structure implies a user role, so we'll keep that.
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        // Omit thinkingConfig to use default (enabled) for higher quality parsing
      }
    });
    
    // FIX: Access text directly from response.
    let jsonStr = result.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    const parsedTask = JSON.parse(jsonStr) as Partial<Task>;
    // Basic validation
    if (parsedTask.title && typeof parsedTask.title === 'string') {
        return parsedTask;
    }
    console.error("Parsed task is not in expected format:", parsedTask);
    return null;

  } catch (error) {
    console.error("Error parsing task with Gemini:", error);
    return null;
  }
};


export const suggestDetailsForTask = async (taskTitle: string, taskDescription?: string): Promise<AITaskSuggestion | null> => {
  const client = getAiClient();
  if (!client) return null;

  const promptParts: Part[] = [{ text: `Task Title: ${taskTitle}` }];
  if (taskDescription) {
    promptParts.push({ text: `Task Description: ${taskDescription}` });
  }
  promptParts.push({text: `Based on the task title and description, suggest relevant tags (array of strings), a category (string), assignees (array of user IDs - use placeholder like user_id_1, user_id_2 if specific users are not known from context), and priority (Low, Medium, High, Urgent).
  Respond ONLY with a JSON object. Example:
  {"tags": ["development", "bugfix"], "category": "Software Development", "assignees": ["user_id_1"], "priority": "High"}
  `});

  try {
    // FIX: Use client.models.generateContent
    const result: GenerateContentResponse = await client.models.generateContent({
        model: TEXT_MODEL,
        // FIX: Ensure contents structure is correct.
        contents: [{ role: "user", parts: promptParts }],
        config: {
            responseMimeType: "application/json",
        }
    });
    
    // FIX: Access text directly from response.
    let jsonStr = result.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    const suggestions = JSON.parse(jsonStr) as AITaskSuggestion;
    return suggestions;
  } catch (error) {
    console.error("Error getting suggestions from Gemini:", error);
    return null;
  }
};

export const generateTextWithGoogleSearch = async (prompt: string): Promise<{ text: string, sources: GroundingChunk[] }> => {
  const client = getAiClient();
  if (!client) return { text: "Error: Gemini client not initialized.", sources: [] };

  try {
    // FIX: Use client.models.generateContent
    const result: GenerateContentResponse = await client.models.generateContent({
      model: TEXT_MODEL,
      // FIX: Ensure contents structure is correct.
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: {
        tools: [{ googleSearch: {} }],
      }
    });

    // FIX: Access text directly from response.
    const text = result.text;
    const groundingMetadata = result.candidates?.[0]?.groundingMetadata;
    const sources: GroundingChunk[] = groundingMetadata?.groundingChunks || [];
    
    return { text, sources };

  } catch (error) {
    console.error("Error generating text with Google Search grounding:", error);
    let errorMessage = "An error occurred while fetching information.";
    if (error instanceof Error) {
        errorMessage = error.message;
    }
    return { text: `Error: ${errorMessage}`, sources: [] };
  }
};
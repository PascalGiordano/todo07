
export interface User {
  userId: string;
  email: string;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
  initials: string;
  avatarBackgroundColor: string; // Hex color
  teams: string[]; // Array of teamId
  createdAt: string; // Timestamp
}

export enum ProjectStatus {
  NotStarted = "Not Started",
  InProgress = "In Progress",
  Completed = "Completed",
  OnHold = "On Hold",
}

export interface Project {
  projectId: string;
  projectName: string;
  description: string; // Rich text
  ownerId: string; // Ref Users
  teamId?: string; // Ref Teams
  startDate: string; // Date
  endDate: string; // Date
  status: ProjectStatus;
  isFavorite: boolean;
  tasks: string[]; // Array of taskId
}

export enum TaskStatus {
  ToDo = "To Do",
  InProgress = "In Progress",
  ReviewQA = "Review/QA",
  Done = "Done",
}

export enum TaskPriority {
  Low = "Low",
  Medium = "Medium",
  High = "High",
  Urgent = "Urgent",
}

export interface Attachment {
  fileName: string;
  url: string;
  uploadedAt: string; // Timestamp
}

export interface Subtask {
  subtaskId: string;
  subtaskName: string;
  isCompleted: boolean;
}

export interface ChecklistItem {
  itemId: string;
  itemName: string;
  isCompleted: boolean;
  relatedAction?: string;
}

export interface Checklist {
  checklistId: string;
  title: string;
  items: ChecklistItem[];
}

export interface Comment {
  commentId: string;
  userId: string; // Ref Users
  content: string;
  createdAt: string; // Timestamp
}

export interface Category {
  categoryId: string;
  categoryName: string;
  color: string; // Hex color
}

export interface Task {
  taskId: string;
  title: string;
  description: string; // Rich text/Markdown
  status: TaskStatus;
  priority: TaskPriority;
  categoryId?: string; // Ref Categories
  dueDate?: string; // Timestamp
  projectId: string; // Ref Projects
  tags: string[]; // Array of tagId
  assignees: string[]; // Array of userId
  attachments: Attachment[];
  subtasks: Subtask[];
  checklists: Checklist[]; // Modified from string[] to Checklist[]
  comments: Comment[];
  createdAt: string; // Timestamp
}

export interface Tag {
  tagId: string;
  tagName: string;
  color: string; // Hex color
}

export interface Team {
  teamId: string;
  teamName: string;
  members: string[]; // Array of userId
}

// For AI suggestions
export interface AITaskSuggestion {
  tags?: string[];
  category?: string; // Suggestion for category name, not ID
  assignees?: string[]; // User IDs
  priority?: TaskPriority;
}

export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web?: GroundingChunkWeb;
  retrievedContext?: {
    uri: string;
    title: string;
  };
  // Add other potential grounding chunk types if needed
}

// Props for EditProjectModal
export interface EditProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  onSave: (updatedProject: Project) => void;
}

// Props for CreateTaskModal
export interface CreateTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  projectId: string;
  onSave: (newTask: Task) => void;
}

// Props for RichTextEditor
export interface RichTextEditorProps {
  value: string;
  onChange: (htmlContent: string) => void;
  placeholder?: string;
  className?: string;
  label?: string;
  id?: string;
  wrapperClassName?: string;
}

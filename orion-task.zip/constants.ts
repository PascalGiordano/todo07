
import { User, Project, Task, Tag, Team, ProjectStatus, TaskStatus, TaskPriority, Category, Checklist, ChecklistItem } from './types';

export const COLORS = {
  primary: '#8A5CF5', // Blue/Violet for action
  success: '#2DA44E', // Green for completion
  warning: '#F5A623', // Orange/Yellow for attention
  danger: '#E53E3E',  // Red for urgency
  darkBg: '#161B22', // Charcoal Gray
  darkBgLighter: '#1F2937', // Slightly lighter for cards/modals
  darkText: '#E5E7EB', // Light gray text
  darkTextSecondary: '#9CA3AF', // Medium gray text
  sidebarBg: '#0D1117', // Dark Blue Night for sidebar
};

export const PRIORITY_COLORS: { [key in TaskPriority]: string } = {
  [TaskPriority.Urgent]: COLORS.danger,
  [TaskPriority.High]: '#F97316', // Orange-red
  [TaskPriority.Medium]: COLORS.warning,
  [TaskPriority.Low]: '#3B82F6', // Blue
};

export const STATUS_COLORS: { [key in TaskStatus]: string } = {
  [TaskStatus.ToDo]: '#6B7280', // Gray
  [TaskStatus.InProgress]: '#3B82F6', // Blue
  [TaskStatus.ReviewQA]: '#EAB308', // Yellow
  [TaskStatus.Done]: COLORS.success,
};

export const MOCK_USERS: User[] = [
  {
    userId: 'user1',
    email: 'alice@example.com',
    firstName: 'Alice',
    lastName: 'Wonderland',
    initials: 'AW',
    avatarBackgroundColor: '#4A00E0',
    teams: ['team1'],
    createdAt: new Date().toISOString(),
    avatarUrl: 'https://picsum.photos/seed/alice/100/100'
  },
  {
    userId: 'user2',
    email: 'bob@example.com',
    firstName: 'Bob',
    lastName: 'The Builder',
    initials: 'BB',
    avatarBackgroundColor: '#E94057',
    teams: ['team1', 'team2'],
    createdAt: new Date().toISOString(),
    avatarUrl: 'https://picsum.photos/seed/bob/100/100'
  },
  {
    userId: 'user3',
    email: 'charlie@example.com',
    firstName: 'Charlie',
    lastName: 'Chaplin',
    initials: 'CC',
    avatarBackgroundColor: '#2DA44E',
    teams: ['team2'],
    createdAt: new Date().toISOString(),
  },
];

export const MOCK_TAGS: Tag[] = [
  { tagId: 'tag1', tagName: 'Frontend', color: '#3B82F6' },
  { tagId: 'tag2', tagName: 'Backend', color: '#10B981' },
  { tagId: 'tag3', tagName: 'Bug', color: '#EF4444' },
  { tagId: 'tag4', tagName: 'Feature', color: '#8B5CF6' },
  { tagId: 'tag5', tagName: 'Urgent', color: '#F59E0B' },
];

export const MOCK_CATEGORIES: Category[] = [
  { categoryId: 'cat1', categoryName: 'Planning', color: '#A78BFA' }, // Violet
  { categoryId: 'cat2', categoryName: 'Design', color: '#F472B6' },   // Pink
  { categoryId: 'cat3', categoryName: 'Development', color: '#60A5FA' }, // Blue
  { categoryId: 'cat4', categoryName: 'Testing', color: '#34D399' },  // Emerald
  { categoryId: 'cat5', categoryName: 'Deployment', color: '#FBBF24' },// Amber
  { categoryId: 'cat6', categoryName: 'Documentation', color: '#9CA3AF' }, // Gray
];


export const MOCK_PROJECTS: Project[] = [
  {
    projectId: 'proj1',
    projectName: 'Orion Task App Development',
    description: 'Full development cycle for the Orion Task application.',
    ownerId: 'user1',
    teamId: 'team1',
    startDate: new Date(2024, 0, 1).toISOString(),
    endDate: new Date(2024, 11, 31).toISOString(),
    status: ProjectStatus.InProgress,
    isFavorite: true,
    tasks: ['task1', 'task2', 'task3', 'task4'],
  },
  {
    projectId: 'proj2',
    projectName: 'Marketing Campaign Q3',
    description: 'Plan and execute the Q3 marketing campaign.',
    ownerId: 'user2',
    teamId: 'team2',
    startDate: new Date(2024, 5, 1).toISOString(),
    endDate: new Date(2024, 8, 30).toISOString(),
    status: ProjectStatus.NotStarted,
    isFavorite: false,
    tasks: ['task5'],
  },
];

const sampleChecklist1: Checklist = {
  checklistId: 'cl1-task1',
  title: 'Design Steps',
  items: [
    { itemId: 'cli1-1', itemName: 'Initial sketches', isCompleted: true },
    { itemId: 'cli1-2', itemName: 'Wireframes approval', isCompleted: true },
    { itemId: 'cli1-3', itemName: 'High-fidelity mockups', isCompleted: false },
    { itemId: 'cli1-4', itemName: 'Prototype creation', isCompleted: false },
  ]
};

const sampleChecklist2: Checklist = {
  checklistId: 'cl2-task1',
  title: 'Pre-launch QA',
  items: [
    { itemId: 'cli2-1', itemName: 'Test on Chrome', isCompleted: true },
    { itemId: 'cli2-2', itemName: 'Test on Firefox', isCompleted: false },
    { itemId: 'cli2-3', itemName: 'Test on Safari', isCompleted: false },
    { itemId: 'cli2-4', itemName: 'Mobile responsiveness check', isCompleted: true },
  ]
};


export const MOCK_TASKS: Task[] = [
  {
    taskId: 'task1',
    title: 'Design Landing Page',
    description: 'Create mockups and final design for the Orion Task landing page. Focus on modern aesthetics and clear call to action.',
    status: TaskStatus.InProgress,
    priority: TaskPriority.High,
    categoryId: 'cat2',
    dueDate: new Date(2024, 6, 15).toISOString(),
    projectId: 'proj1',
    tags: ['tag1', 'tag4'],
    assignees: ['user1'],
    attachments: [{ fileName: 'brief.pdf', url: '#', uploadedAt: new Date().toISOString() }],
    subtasks: [
      { subtaskId: 'sub1', subtaskName: 'Wireframes', isCompleted: true },
      { subtaskId: 'sub2', subtaskName: 'UI Mockup', isCompleted: false },
    ],
    checklists: [sampleChecklist1, sampleChecklist2], // Added sample checklists
    comments: [
      { commentId: 'cmt1', userId: 'user2', content: 'Looking good so far!', createdAt: new Date().toISOString() }
    ],
    createdAt: new Date().toISOString(),
  },
  {
    taskId: 'task2',
    title: 'Develop Authentication Module',
    description: 'Implement user registration, login, and session management.',
    status: TaskStatus.ToDo,
    priority: TaskPriority.Urgent,
    categoryId: 'cat3',
    dueDate: new Date(2024, 6, 20).toISOString(),
    projectId: 'proj1',
    tags: ['tag2', 'tag3'],
    assignees: ['user2'],
    attachments: [],
    subtasks: [],
    checklists: [
        {
            checklistId: 'cl1-task2',
            title: 'Security Checks',
            items: [
                { itemId: 'cli2-1-1', itemName: 'Password hashing (bcrypt)', isCompleted: false},
                { itemId: 'cli2-1-2', itemName: 'Input sanitization', isCompleted: false},
                { itemId: 'cli2-1-3', itemName: 'Rate limiting', isCompleted: false},
            ]
        }
    ],
    comments: [],
    createdAt: new Date().toISOString(),
  },
  {
    taskId: 'task3',
    title: 'Setup CI/CD Pipeline',
    description: 'Configure continuous integration and deployment for the project.',
    status: TaskStatus.ToDo,
    priority: TaskPriority.Medium,
    categoryId: 'cat5',
    projectId: 'proj1',
    tags: ['tag2'],
    assignees: ['user2', 'user3'],
    attachments: [],
    subtasks: [],
    checklists: [],
    comments: [],
    createdAt: new Date().toISOString(),
  },
  {
    taskId: 'task4',
    title: 'User Profile Page',
    description: 'Develop the user profile page with editable fields.',
    status: TaskStatus.ReviewQA,
    priority: TaskPriority.Medium,
    categoryId: 'cat3',
    dueDate: new Date(2024, 7, 1).toISOString(),
    projectId: 'proj1',
    tags: ['tag1'],
    assignees: ['user1'],
    attachments: [],
    subtasks: [ { subtaskId: 'sub3', subtaskName: 'Test on mobile', isCompleted: false } ],
    checklists: [],
    comments: [],
    createdAt: new Date().toISOString(),
  },
  {
    taskId: 'task5',
    title: 'Define Target Audience for Q3 Campaign',
    description: 'Research and define the primary target audience for the upcoming Q3 marketing campaign.',
    status: TaskStatus.ToDo,
    priority: TaskPriority.High,
    categoryId: 'cat1',
    projectId: 'proj2',
    tags: [],
    assignees: ['user2'],
    attachments: [],
    subtasks: [],
    checklists: [],
    comments: [],
    createdAt: new Date().toISOString(),
  },
];

export const MOCK_TEAMS: Team[] = [
  { teamId: 'team1', teamName: 'Core Development', members: ['user1', 'user2'] },
  { teamId: 'team2', teamName: 'Marketing', members: ['user2', 'user3'] },
];

export const GEMINI_API_KEY = process.env.API_KEY;

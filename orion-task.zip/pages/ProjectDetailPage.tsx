
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Project, Task, User, Team } from '../types';
import { MOCK_PROJECTS, MOCK_TASKS, MOCK_USERS, MOCK_TEAMS, COLORS } from '../constants';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Avatar } from '../components/ui/Avatar';
import { TaskCard } from '../components/TaskCard';
import { TaskDetailModal } from '../components/TaskDetailModal';
import { EditProjectModal } from '../components/EditProjectModal';
import { CreateTaskModal } from '../components/CreateTaskModal';
import { formatDate, classNames } from '../utils/helpers';
import { EditIcon } from '../components/icons/EditIcon';
import { PlusIcon } from '../components/icons/PlusIcon';
import { StarIcon } from '../components/icons/StarIcon';
import { ChevronLeftIcon } from '@heroicons/react/24/solid'; // Using heroicons for back arrow

export const ProjectDetailPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();

  const [project, setProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [owner, setOwner] = useState<User | null>(null);
  const [team, setTeam] = useState<Team | null>(null);

  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isEditProjectModalOpen, setIsEditProjectModalOpen] = useState(false);
  const [isCreateTaskModalOpen, setIsCreateTaskModalOpen] = useState(false);

  // Simulate fetching data - In a real app, this would be an API call
  useEffect(() => {
    const foundProject = MOCK_PROJECTS.find(p => p.projectId === projectId);
    if (foundProject) {
      setProject(foundProject);
      const projectTasks = MOCK_TASKS.filter(t => t.projectId === projectId);
      setTasks(projectTasks);
      setOwner(MOCK_USERS.find(u => u.userId === foundProject.ownerId) || null);
      setTeam(MOCK_TEAMS.find(tm => tm.teamId === foundProject.teamId) || null);
    } else {
      // Handle project not found, e.g., navigate to a 404 page or back
      navigate('/projects');
    }
  }, [projectId, navigate]);

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
  };

  const handleCloseTaskModal = () => {
    setSelectedTask(null);
  };

  const handleUpdateTask = (updatedTask: Task) => {
    setTasks(prevTasks => prevTasks.map(t => t.taskId === updatedTask.taskId ? updatedTask : t));
    // If you want to update MOCK_TASKS globally (for demo purposes, not ideal for real apps)
    const taskIndex = MOCK_TASKS.findIndex(t => t.taskId === updatedTask.taskId);
    if (taskIndex !== -1) MOCK_TASKS[taskIndex] = updatedTask;
  };

  const handleSaveProject = (updatedProject: Project) => {
    setProject(updatedProject);
    // Update MOCK_PROJECTS globally (for demo purposes)
    const projectIndex = MOCK_PROJECTS.findIndex(p => p.projectId === updatedProject.projectId);
    if (projectIndex !== -1) MOCK_PROJECTS[projectIndex] = updatedProject;
    setIsEditProjectModalOpen(false);
  };

  const handleSaveNewTask = (newTask: Task) => {
    setTasks(prevTasks => [newTask, ...prevTasks]);
    // Add to MOCK_TASKS globally (for demo purposes)
    MOCK_TASKS.unshift(newTask);
    setIsCreateTaskModalOpen(false);
  };
  
  const toggleFavorite = () => {
    if (project) {
      const updatedProject = { ...project, isFavorite: !project.isFavorite };
      setProject(updatedProject);
      // Update MOCK_PROJECTS
      const projectIndex = MOCK_PROJECTS.findIndex(p => p.projectId === updatedProject.projectId);
      if (projectIndex !== -1) MOCK_PROJECTS[projectIndex].isFavorite = updatedProject.isFavorite;
    }
  };


  if (!project) {
    return <div className="text-center text-xl text-gray-400 p-10">Loading project details or project not found...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
            <button 
                onClick={() => navigate(-1)} 
                className="p-2 rounded-full hover:bg-gray-700 transition-colors"
                title="Go Back"
            >
                <ChevronLeftIcon className="w-6 h-6 text-gray-300"/>
            </button>
            <h1 className="text-3xl font-bold text-white">{project.projectName}</h1>
            <button onClick={toggleFavorite} title={project.isFavorite ? "Remove from favorites" : "Add to favorites"}>
                <StarIcon className={classNames("w-6 h-6 cursor-pointer", project.isFavorite ? `text-[${COLORS.warning}]` : 'text-gray-500 hover:text-gray-300')} filled={project.isFavorite} />
            </button>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" onClick={() => setIsEditProjectModalOpen(true)} leftIcon={<EditIcon className="w-4 h-4" />}>
            Edit Project
          </Button>
          <Button variant="primary" onClick={() => setIsCreateTaskModalOpen(true)} leftIcon={<PlusIcon className="w-4 h-4" />}>
            Add Task
          </Button>
        </div>
      </div>

      {/* Project Metadata Card */}
      <Card className="bg-opacity-50">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4 text-sm">
          <div>
            <h4 className="text-xs text-gray-400 font-semibold mb-0.5">Owner</h4>
            {owner ? (
              <div className="flex items-center">
                <Avatar user={owner} size="sm" className="mr-2" />
                <span className="text-gray-200">{owner.firstName} {owner.lastName}</span>
              </div>
            ) : <span className="text-gray-300">N/A</span>}
          </div>
          <div>
            <h4 className="text-xs text-gray-400 font-semibold mb-0.5">Team</h4>
            <span className="text-gray-200">{team?.teamName || 'N/A'}</span>
          </div>
          <div>
            <h4 className="text-xs text-gray-400 font-semibold mb-0.5">Status</h4>
            <span className={`px-2 py-0.5 rounded-full text-xs font-medium`} style={{backgroundColor: project.status === 'Completed' ? COLORS.success : COLORS.warning, color: 'black'}}>{project.status}</span>
          </div>
          <div>
            <h4 className="text-xs text-gray-400 font-semibold mb-0.5">Start Date</h4>
            <span className="text-gray-200">{formatDate(project.startDate)}</span>
          </div>
          <div>
            <h4 className="text-xs text-gray-400 font-semibold mb-0.5">End Date</h4>
            <span className="text-gray-200">{formatDate(project.endDate)}</span>
          </div>
          <div className="md:col-span-2 lg:col-span-1">
             <h4 className="text-xs text-gray-400 font-semibold mb-0.5">Progress</h4>
             {(() => {
                const totalTasks = tasks.length;
                const completedTasks = tasks.filter(t => t.status === 'Done').length;
                const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
                return (
                    <div className="flex items-center">
                        <div className="w-full bg-gray-700 rounded-full h-2 mr-2">
                            <div className={`bg-[${COLORS.primary}] h-2 rounded-full`} style={{ width: `${progress}%` }}></div>
                        </div>
                        <span className="text-gray-200 text-xs">{progress}%</span>
                    </div>
                );
             })()}
          </div>
        </div>
        {project.description && (
          <div className="mt-4 pt-4 border-t border-gray-700">
            <h4 className="text-xs text-gray-400 font-semibold mb-1">Description</h4>
            <p className="text-gray-300 whitespace-pre-wrap text-sm">{project.description}</p>
          </div>
        )}
      </Card>

      {/* Tasks Section */}
      <div>
        <h2 className="text-2xl font-semibold text-white mb-4">Tasks ({tasks.length})</h2>
        {tasks.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {tasks.map(task => (
              <TaskCard key={task.taskId} task={task} onClick={handleTaskClick} />
            ))}
          </div>
        ) : (
          <p className="text-gray-400 text-center py-5">No tasks found for this project. Add one!</p>
        )}
      </div>

      {/* Modals */}
      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          isOpen={!!selectedTask}
          onClose={handleCloseTaskModal}
          onUpdateTask={handleUpdateTask}
        />
      )}
      {isEditProjectModalOpen && (
        <EditProjectModal
          isOpen={isEditProjectModalOpen}
          onClose={() => setIsEditProjectModalOpen(false)}
          project={project}
          onSave={handleSaveProject}
        />
      )}
       {isCreateTaskModalOpen && (
        <CreateTaskModal
          isOpen={isCreateTaskModalOpen}
          onClose={() => setIsCreateTaskModalOpen(false)}
          projectId={project.projectId}
          onSave={handleSaveNewTask}
        />
      )}
    </div>
  );
};
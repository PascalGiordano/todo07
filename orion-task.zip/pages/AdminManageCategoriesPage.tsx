
import React, { useState } from 'react';
import { Category } from '../types';
import { MOCK_CATEGORIES, COLORS } from '../constants';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { PlusIcon } from '../components/icons/PlusIcon';
import { Modal } from '../components/ui/Modal';
import { getRandomHexColor } from '../utils/helpers';
import { TrashIcon } from '../components/icons/TrashIcon';
import { EditIcon } from '../components/icons/EditIcon';


export const AdminManageCategoriesPage: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>(MOCK_CATEGORIES);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryColor, setNewCategoryColor] = useState(getRandomHexColor());

  const openModalForCreate = () => {
    setEditingCategory(null);
    setNewCategoryName('');
    setNewCategoryColor(getRandomHexColor());
    setIsModalOpen(true);
  };

  const openModalForEdit = (category: Category) => {
    setEditingCategory(category);
    setNewCategoryName(category.categoryName);
    setNewCategoryColor(category.color);
    setIsModalOpen(true);
  };

  const handleSaveCategory = () => {
    if (!newCategoryName.trim()) return;

    if (editingCategory) {
      setCategories(categories.map(c => c.categoryId === editingCategory.categoryId ? { ...c, categoryName: newCategoryName, color: newCategoryColor } : c));
    } else {
      const newCategory: Category = {
        categoryId: `cat-${Date.now()}`,
        categoryName: newCategoryName,
        color: newCategoryColor,
      };
      setCategories([...categories, newCategory]);
    }
    setIsModalOpen(false);
  };
  
  const handleDeleteCategory = (categoryId: string) => {
    if (window.confirm("Are you sure you want to delete this category? This action cannot be undone.")) {
        setCategories(categories.filter(c => c.categoryId !== categoryId));
    }
  };

  const getTextColorForBackground = (backgroundColor: string): string => {
    const hex = backgroundColor.replace('#', '');
    if (hex.length !== 6) return '#FFFFFF'; // Default to white for invalid hex
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness > 155 ? '#000000' : '#FFFFFF';
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Manage Categories</h1>
        <Button variant="primary" leftIcon={<PlusIcon className="w-5 h-5" />} onClick={openModalForCreate}>
          New Category
        </Button>
      </div>

      <Card>
        {categories.length === 0 ? (
          <p className="text-gray-400">No categories found. Create one!</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-[#0D1117]">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Preview</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Color Hex</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className={`bg-[${COLORS.darkBgLighter}] divide-y divide-gray-700`}>
                {categories.map(category => (
                  <tr key={category.categoryId}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span 
                        className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full" 
                        style={{ backgroundColor: category.color, color: getTextColorForBackground(category.color) }}
                      >
                        {category.categoryName}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-200">{category.categoryName}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{category.color}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => openModalForEdit(category)} title="Edit">
                        <EditIcon className="w-4 h-4" />
                      </Button>
                       <Button variant="ghost" size="sm" onClick={() => handleDeleteCategory(category.categoryId)} className="!text-red-500 hover:!text-red-400" title="Delete">
                        <TrashIcon className="w-4 h-4"/>
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
      
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingCategory ? "Edit Category" : "Create New Category"}>
        <div className="space-y-4">
          <Input 
            label="Category Name"
            value={newCategoryName}
            onChange={(e) => setNewCategoryName(e.target.value)}
            placeholder="Enter category name"
            required
          />
          <div className="flex items-center space-x-3">
            <Input 
              label="Category Color"
              type="color"
              value={newCategoryColor}
              onChange={(e) => setNewCategoryColor(e.target.value)}
              className="p-1 h-10 w-16"
              wrapperClassName="flex-shrink-0"
            />
            <Input
                label="Hex Code"
                value={newCategoryColor}
                onChange={(e) => setNewCategoryColor(e.target.value)}
                placeholder="#RRGGBB"
                className="flex-grow"
            />
          </div>
          <div className="pt-2 flex justify-end space-x-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={handleSaveCategory}>Save Category</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

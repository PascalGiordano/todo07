
import React from 'react';
import { Card } from '../components/ui/Card';
import { MOCK_TEAMS, MOCK_USERS, COLORS } from '../constants';
import { Avatar } from '../components/ui/Avatar';

export const TeamsPage: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-white mb-6">Teams</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {MOCK_TEAMS.map(team => (
          <Card key={team.teamId} title={team.teamName} className={`border-l-4 border-[${COLORS.primary}]`}>
            <p className="text-sm text-gray-400 mb-3">Members: {team.members.length}</p>
            <div className="space-y-2">
              {team.members.map(memberId => {
                const member = MOCK_USERS.find(u => u.userId === memberId);
                if (!member) return null;
                return (
                  <div key={memberId} className="flex items-center p-2 bg-[#0D1117] rounded-md">
                    <Avatar user={member} size="sm" />
                    <span className="ml-3 text-sm text-gray-200">{member.firstName} {member.lastName}</span>
                  </div>
                );
              })}
            </div>
             <p className="text-gray-400 text-sm mt-4">Team workload visualization and management features will be here.</p>
          </Card>
        ))}
      </div>
       <Card className="mt-6">
        <p className="text-gray-300">
         Full team management features (add/remove members, assign roles, view overall workload) will be implemented here.
        </p>
      </Card>
    </div>
  );
};
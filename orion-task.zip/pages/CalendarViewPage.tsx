
import React from 'react';
import { Card } from '../components/ui/Card';
import { COLORS } from '../constants';

export const CalendarViewPage: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-white mb-6">Calendar View</h1>
      <Card>
        <p className="text-gray-300">
          Calendar View is under construction. This page will display tasks with due dates in a monthly/weekly calendar format.
          It might integrate with external calendars like Google Calendar or Outlook.
        </p>
        <div className="mt-6 h-96 bg-[#0D1117] rounded-md flex items-center justify-center border border-dashed border-gray-600">
          <p className="text-gray-500 text-lg">Calendar Placeholder</p>
        </div>
      </Card>
    </div>
  );
};
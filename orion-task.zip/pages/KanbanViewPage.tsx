
import React, { useState } from 'react';
import { Task, TaskStatus } from '../types';
import { MOCK_TASKS, COLORS, STATUS_COLORS } from '../constants';
import { TaskCard } from '../components/TaskCard';
import { TaskDetailModal } from '../components/TaskDetailModal';
import { Button } from '../components/ui/Button';
import { PlusIcon } from '../components/icons/PlusIcon';

// Dummy drag and drop state, in reality use a library like react-beautiful-dnd
interface DragItem {
  task: Task;
  fromStatus: TaskStatus;
}

export const KanbanViewPage: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [draggingItem, setDraggingItem] = useState<DragItem | null>(null);

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
  };

  const handleCloseModal = () => {
    setSelectedTask(null);
  };
  
  const handleUpdateTask = (updatedTask: Task) => {
    setTasks(prevTasks => prevTasks.map(t => t.taskId === updatedTask.taskId ? updatedTask : t));
    // If selected task is updated, refresh it in modal too
    if (selectedTask && selectedTask.taskId === updatedTask.taskId) {
      setSelectedTask(updatedTask);
    }
  };

  const columns: TaskStatus[] = [TaskStatus.ToDo, TaskStatus.InProgress, TaskStatus.ReviewQA, TaskStatus.Done];

  // Basic drag and drop simulation
  const handleDragStart = (task: Task, fromStatus: TaskStatus) => {
    setDraggingItem({ task, fromStatus });
  };

  const handleDrop = (toStatus: TaskStatus) => {
    if (draggingItem) {
      const updatedTasks = tasks.map(t => 
        t.taskId === draggingItem.task.taskId ? { ...t, status: toStatus } : t
      );
      setTasks(updatedTasks);
      setDraggingItem(null);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault(); // Necessary to allow dropping
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex justify-between items-center mb-6 px-1">
        <h1 className="text-3xl font-bold text-white">Kanban Board</h1>
        <Button variant="primary" leftIcon={<PlusIcon className="w-5 h-5"/>}>New Task</Button>
      </div>

      <div className="flex-grow grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 overflow-x-auto pb-4">
        {columns.map(status => (
          <div
            key={status}
            className="bg-[${COLORS.darkBg}] p-4 rounded-lg shadow-sm min-h-[300px] flex flex-col"
            onDrop={() => handleDrop(status)}
            onDragOver={handleDragOver}
          >
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-semibold text-lg text-white flex items-center">
                <span className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: STATUS_COLORS[status] }}></span>
                {status}
              </h2>
              <span className="text-sm text-gray-400">
                {tasks.filter(t => t.status === status).length}
              </span>
            </div>
            <div className="flex-grow space-y-3 overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800">
              {tasks.filter(t => t.status === status).map(task => (
                <div 
                  key={task.taskId}
                  draggable
                  onDragStart={() => handleDragStart(task, status)}
                >
                  <TaskCard task={task} onClick={handleTaskClick} isDraggable={true} />
                </div>
              ))}
               {tasks.filter(t => t.status === status).length === 0 && (
                <p className="text-sm text-gray-500 text-center py-4">No tasks in this column.</p>
              )}
            </div>
             <Button variant="ghost" size="sm" className="w-full mt-3" leftIcon={<PlusIcon className="w-4 h-4" />}>Add Task</Button>
          </div>
        ))}
      </div>

      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          isOpen={!!selectedTask}
          onClose={handleCloseModal}
          onUpdateTask={handleUpdateTask}
        />
      )}
    </div>
  );
};
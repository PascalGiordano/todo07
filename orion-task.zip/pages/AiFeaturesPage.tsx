
import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Input, Textarea } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { COLORS, GEMINI_API_KEY } from '../constants';
import { parseTaskFromNaturalLanguage, suggestDetailsForTask, generateTextWithGoogleSearch } from '../services/geminiService';
// FIX: Import TaskStatus and TaskPriority enums for type safety
import { Task, AITaskSuggestion, GroundingChunk, TaskStatus, TaskPriority } from '../types';
import { TaskCard } from '../components/TaskCard'; // To display created task

export const AiFeaturesPage: React.FC = () => {
  const [naturalLanguageInput, setNaturalLanguageInput] = useState('');
  const [createdTask, setCreatedTask] = useState<Partial<Task> | null>(null);
  const [isLoadingNL, setIsLoadingNL] = useState(false);

  const [taskTitleForSuggestion, setTaskTitleForSuggestion] = useState('');
  const [taskDescForSuggestion, setTaskDescForSuggestion] = useState('');
  const [suggestedDetails, setSuggestedDetails] = useState<AITaskSuggestion | null>(null);
  const [isLoadingSuggest, setIsLoadingSuggest] = useState(false);

  const [searchPrompt, setSearchPrompt] = useState('');
  const [searchResults, setSearchResults] = useState<{text: string, sources: GroundingChunk[]} | null>(null);
  const [isLoadingSearch, setIsLoadingSearch] = useState(false);


  const handleCreateTaskFromNL = async () => {
    if (!naturalLanguageInput.trim()) return;
    setIsLoadingNL(true);
    setCreatedTask(null);
    const task = await parseTaskFromNaturalLanguage(naturalLanguageInput);
    if (task) {
      // For demo, assign a temp ID and other required fields if missing
      const fullTask: Task = {
        taskId: `ai-${Date.now()}`,
        title: task.title || 'AI Generated Task',
        description: task.description || '',
        // FIX: Use TaskStatus enum member for default value
        status: task.status || TaskStatus.ToDo,
        // FIX: Use TaskPriority enum member for default value
        priority: task.priority || TaskPriority.Medium,
        projectId: 'proj-ai', // dummy project
        tags: task.tags || [],
        assignees: task.assignees || [],
        attachments: [],
        subtasks: [],
        checklists: [],
        comments: [],
        createdAt: new Date().toISOString(),
        dueDate: task.dueDate,
        ...task, // Spread the AI parsed task to override defaults
      };
      setCreatedTask(fullTask);
    } else {
      alert('Failed to parse task. Check console for errors.');
    }
    setIsLoadingNL(false);
  };

  const handleSuggestDetails = async () => {
    if (!taskTitleForSuggestion.trim()) return;
    setIsLoadingSuggest(true);
    setSuggestedDetails(null);
    const suggestions = await suggestDetailsForTask(taskTitleForSuggestion, taskDescForSuggestion);
    setSuggestedDetails(suggestions);
    setIsLoadingSuggest(false);
  };

  const handleSearchGrounding = async () => {
    if(!searchPrompt.trim()) return;
    setIsLoadingSearch(true);
    setSearchResults(null);
    const results = await generateTextWithGoogleSearch(searchPrompt);
    setSearchResults(results);
    setIsLoadingSearch(false);
  };

  if (!GEMINI_API_KEY) {
    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-white">AI Features</h1>
             <Card title="API Key Not Configured">
                <p className="text-lg text-yellow-400">
                    The Gemini API Key (API_KEY) is not set in your environment variables.
                </p>
                <p className="mt-2 text-gray-300">
                    Please configure the API_KEY to use AI features. This application is designed to read the key from `process.env.API_KEY` and will not prompt you to enter it here.
                </p>
            </Card>
        </div>
    );
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-white">AI-Powered Features (Gemini)</h1>

      {/* Natural Language Task Creation */}
      <Card title="Create Task from Natural Language">
        <p className="text-sm text-gray-400 mb-3">
          Type a task description like "Schedule meeting with design team for next Tuesday at 2 PM to review mockups, high priority".
        </p>
        <Textarea
          value={naturalLanguageInput}
          onChange={(e) => setNaturalLanguageInput(e.target.value)}
          placeholder="e.g., Finish quarterly report by end of next week"
          rows={3}
        />
        <Button onClick={handleCreateTaskFromNL} isLoading={isLoadingNL} disabled={isLoadingNL} className="mt-3">
          {isLoadingNL ? 'Processing...' : 'Create Task with AI'}
        </Button>
        {createdTask && (
          <div className="mt-4 p-4 border border-dashed border-[${COLORS.primary}] rounded-md">
            <h4 className="text-md font-semibold text-gray-200 mb-2">Parsed Task:</h4>
            <TaskCard task={createdTask as Task} />
          </div>
        )}
      </Card>

      {/* Intelligent Suggestions */}
      <Card title="AI Task Suggestions">
        <p className="text-sm text-gray-400 mb-3">
          Enter a task title and (optionally) description, and AI will suggest tags, category, assignees, and priority.
        </p>
        <Input
          label="Task Title"
          value={taskTitleForSuggestion}
          onChange={(e) => setTaskTitleForSuggestion(e.target.value)}
          placeholder="e.g., Fix login button bug"
        />
        <Textarea
          label="Task Description (Optional)"
          value={taskDescForSuggestion}
          onChange={(e) => setTaskDescForSuggestion(e.target.value)}
          placeholder="e.g., The login button on the main page is not working on Safari."
          rows={3}
        />
        <Button onClick={handleSuggestDetails} isLoading={isLoadingSuggest} disabled={isLoadingSuggest} className="mt-3">
          {isLoadingSuggest ? 'Getting Suggestions...' : 'Get AI Suggestions'}
        </Button>
        {suggestedDetails && (
          <div className="mt-4 p-4 bg-[#0D1117] rounded-md">
            <h4 className="text-md font-semibold text-gray-200 mb-2">AI Suggestions:</h4>
            <pre className="text-xs text-gray-300 whitespace-pre-wrap bg-black p-2 rounded">
              {JSON.stringify(suggestedDetails, null, 2)}
            </pre>
          </div>
        )}
      </Card>

       {/* Google Search Grounding */}
      <Card title="Information Lookup with Google Search Grounding">
        <p className="text-sm text-gray-400 mb-3">
          Ask a question that might require up-to-date information from the web.
        </p>
        <Input
          value={searchPrompt}
          onChange={(e) => setSearchPrompt(e.target.value)}
          placeholder="e.g., What were the key announcements at the latest Google I/O?"
        />
        {/* FIX: Corrected typo in function call handleSearchGounding to handleSearchGrounding */}
        <Button onClick={handleSearchGrounding} isLoading={isLoadingSearch} disabled={isLoadingSearch} className="mt-3">
          {isLoadingSearch ? 'Searching...' : 'Ask AI with Search'}
        </Button>
        {searchResults && (
          <div className="mt-4 p-4 bg-[#0D1117] rounded-md">
            <h4 className="text-md font-semibold text-gray-200 mb-1">AI Response:</h4>
            <p className="text-gray-300 whitespace-pre-wrap mb-3">{searchResults.text}</p>
            {searchResults.sources && searchResults.sources.length > 0 && (
                 <>
                    <h5 className="text-sm font-semibold text-gray-400 mb-1">Sources:</h5>
                    <ul className="list-disc list-inside text-xs space-y-1">
                    {searchResults.sources.map((source, index) => {
                        const uri = source.web?.uri || source.retrievedContext?.uri;
                        const title = source.web?.title || source.retrievedContext?.title;
                        if (uri) {
                            return (
                                <li key={index}>
                                    <a href={uri} target="_blank" rel="noopener noreferrer" className="text-[${COLORS.primary}] hover:underline">
                                        {title || uri}
                                    </a>
                                </li>
                            );
                        }
                        return null;
                    })}
                    </ul>
                </>
            )}
          </div>
        )}
      </Card>

      {/* Placeholder for Risk Detection & Auto-Sort Widgets */}
      <Card title="Advanced AI Insights (Future Features)">
         <p className="text-sm text-gray-400">
          Future AI capabilities will include:
        </p>
        <ul className="list-disc list-inside text-sm text-gray-300 mt-2 space-y-1">
            <li><strong>Risk Detection:</strong> AI analysis of project progress to identify potential delays or bottlenecks.</li>
            <li><strong>Smart Task Sorting:</strong> Automatic prioritization of tasks based on urgency, importance, and dependencies.</li>
        </ul>
      </Card>
    </div>
  );
};
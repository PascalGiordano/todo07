
import React, { useState, useMemo } from 'react';
import { Project, Task, User, ProjectStatus } from '../types';
import { MOCK_PROJECTS, MOCK_TASKS, MOCK_USERS, COLORS } from '../constants';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { PlusIcon } from '../components/icons/PlusIcon';
import { Link } from 'react-router-dom';
import { Avatar } from '../components/ui/Avatar';
import { formatDate } from '../utils/helpers';
import { Modal } from '../components/ui/Modal';
import { Input, Textarea } from '../components/ui/Input'; // Textarea for new project description
import { RichTextEditor } from '../components/ui/RichTextEditor'; // For new project description potentially

interface ProjectCardProps {
  project: Project;
}

const ProjectListItem: React.FC<ProjectCardProps> = ({ project }) => {
  const owner = MOCK_USERS.find(u => u.userId === project.ownerId);
  const tasksCount = MOCK_TASKS.filter(t => t.projectId === project.projectId).length;
  const completedTasksCount = MOCK_TASKS.filter(t => t.projectId === project.projectId && t.status === 'Done').length;
  const progress = tasksCount > 0 ? Math.round((completedTasksCount / tasksCount) * 100) : 0;

  return (
    <Card className={`border-l-4 border-[${COLORS.primary}] hover:shadow-xl transition-all duration-200`}>
      <div className="flex justify-between items-start">
        <Link to={`/projects/${project.projectId}`} className={`text-xl font-semibold text-white hover:text-[${COLORS.primary}] transition-colors`}>
          {project.projectName}
        </Link>
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          project.status === ProjectStatus.Completed ? `bg-[${COLORS.success}] text-black` :
          project.status === ProjectStatus.InProgress ? `bg-[${COLORS.warning}] text-black` :
          project.status === ProjectStatus.OnHold ? 'bg-gray-500 text-white' :
          'bg-blue-500 text-white'
        }`}>
          {project.status}
        </span>
      </div>
      <p className="text-sm text-gray-400 mt-1 mb-3 line-clamp-2">{project.description.replace(/<[^>]+>/g, '')}</p>
      
      <div className="mb-3">
        <div className="flex justify-between items-center text-xs text-gray-400 mb-1">
          <span>Progress</span>
          <span>{progress}%</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-1.5">
          <div className={`bg-[${COLORS.primary}] h-1.5 rounded-full`} style={{ width: `${progress}%` }}></div>
        </div>
      </div>

      <div className="flex justify-between items-center text-sm text-gray-400">
        <div className="flex items-center">
          {owner && <Avatar user={owner} size="sm" className="mr-2"/> }
          <span>{owner ? `${owner.firstName} ${owner.lastName}` : 'N/A'}</span>
        </div>
        <div className="text-right">
          <p>Due: {formatDate(project.endDate)}</p>
          <p>{tasksCount} tasks</p>
        </div>
      </div>
    </Card>
  );
};

type SortKey = 'projectName' | 'endDate' | 'status';
type SortDirection = 'asc' | 'desc';

export const ProjectsListPage: React.FC = () => {
  const [projectsData, setProjectsData] = useState<Project[]>(MOCK_PROJECTS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newProject, setNewProject] = useState<Partial<Project>>({
    projectName: '',
    description: '',
    status: ProjectStatus.NotStarted,
    isFavorite: false,
    ownerId: MOCK_USERS[0]?.userId || '' 
  });

  const [filterStatus, setFilterStatus] = useState<ProjectStatus | ''>('');
  const [filterOwner, setFilterOwner] = useState<string>('');
  const [sortBy, setSortBy] = useState<SortKey>('projectName');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  const handleInputChange = (field: keyof Project, value: any) => {
    setNewProject(prev => ({ ...prev, [field]: value }));
  };
  
  const handleDescriptionChange = (htmlContent: string) => {
    setNewProject(prev => ({ ...prev, description: htmlContent }));
  };

  const handleCreateProject = () => {
    if (newProject.projectName && newProject.description) {
      const projectToAdd: Project = {
        ...newProject,
        projectId: `proj-${Date.now()}`,
        startDate: newProject.startDate || new Date().toISOString(),
        endDate: newProject.endDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), 
        tasks: [],
      } as Project;
      setProjectsData(prev => [projectToAdd, ...prev]);
      // Also update MOCK_PROJECTS for global consistency in demo
      MOCK_PROJECTS.unshift(projectToAdd);
      setIsModalOpen(false);
      setNewProject({ projectName: '', description: '', status: ProjectStatus.NotStarted, isFavorite: false, ownerId: MOCK_USERS[0]?.userId || '' });
    }
  };

  const filteredAndSortedProjects = useMemo(() => {
    let result = [...projectsData];

    if (filterStatus) {
      result = result.filter(p => p.status === filterStatus);
    }
    if (filterOwner) {
      result = result.filter(p => p.ownerId === filterOwner);
    }

    result.sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'projectName') {
        comparison = a.projectName.localeCompare(b.projectName);
      } else if (sortBy === 'endDate') {
        comparison = new Date(a.endDate).getTime() - new Date(b.endDate).getTime();
      } else if (sortBy === 'status') {
        comparison = a.status.localeCompare(b.status);
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [projectsData, filterStatus, filterOwner, sortBy, sortDirection]);


  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-white">Projects</h1>
        <Button variant="primary" leftIcon={<PlusIcon className="w-5 h-5" />} onClick={() => setIsModalOpen(true)}>
          New Project
        </Button>
      </div>

      {/* Filters and Sort */}
      <Card className="!p-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 items-end">
          <div>
            <label htmlFor="filterStatus" className="block text-xs font-medium text-gray-400 mb-1">Filter by Status</label>
            <select 
              id="filterStatus" 
              value={filterStatus} 
              onChange={(e) => setFilterStatus(e.target.value as ProjectStatus | '')}
              className={`w-full p-2 text-sm rounded-md border bg-[#0D1117] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
            >
              <option value="">All Statuses</option>
              {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="filterOwner" className="block text-xs font-medium text-gray-400 mb-1">Filter by Owner</label>
            <select 
              id="filterOwner" 
              value={filterOwner} 
              onChange={(e) => setFilterOwner(e.target.value)}
              className={`w-full p-2 text-sm rounded-md border bg-[#0D1117] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
            >
              <option value="">All Owners</option>
              {MOCK_USERS.map(u => <option key={u.userId} value={u.userId}>{u.firstName} {u.lastName}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="sortBy" className="block text-xs font-medium text-gray-400 mb-1">Sort By</label>
            <select 
              id="sortBy" 
              value={sortBy} 
              onChange={(e) => setSortBy(e.target.value as SortKey)}
              className={`w-full p-2 text-sm rounded-md border bg-[#0D1117] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
            >
              <option value="projectName">Name</option>
              <option value="endDate">End Date</option>
              <option value="status">Status</option>
            </select>
          </div>
          <div>
            <Button 
              variant="ghost" 
              onClick={() => setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc')}
              className="w-full"
            >
              {sortDirection === 'asc' ? 'Ascending ↑' : 'Descending ↓'}
            </Button>
          </div>
        </div>
      </Card>
      
      {filteredAndSortedProjects.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAndSortedProjects.map(project => (
            <ProjectListItem key={project.projectId} project={project} />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-400 py-10">No projects match your criteria.</p>
      )}


      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Create New Project">
        <div className="space-y-4">
          <Input 
            label="Project Name"
            value={newProject.projectName || ''}
            onChange={(e) => handleInputChange('projectName', e.target.value)}
            placeholder="Enter project name"
            required
          />
          <RichTextEditor
            label="Description"
            id="newProjectDescription"
            value={newProject.description || ''}
            onChange={handleDescriptionChange}
            placeholder="Enter project description..."
          />
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Status</label>
            <select
                value={newProject.status}
                onChange={(e) => handleInputChange('status', e.target.value as ProjectStatus)}
                className={`w-full p-2 text-sm rounded-md border bg-[#161B22] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
            >
                {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
           <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Owner</label>
            <select
                value={newProject.ownerId}
                onChange={(e) => handleInputChange('ownerId', e.target.value)}
                className={`w-full p-2 text-sm rounded-md border bg-[#161B22] text-white border-gray-600 focus:ring-[${COLORS.primary}] focus:border-[${COLORS.primary}]`}
            >
                {MOCK_USERS.map(u => <option key={u.userId} value={u.userId}>{u.firstName} {u.lastName}</option>)}
            </select>
          </div>
          <Input 
            label="Start Date"
            type="date"
            value={newProject.startDate ? newProject.startDate.split('T')[0] : ''}
            onChange={(e) => handleInputChange('startDate', e.target.value ? new Date(e.target.value).toISOString() : '')}
          />
          <Input 
            label="End Date"
            type="date"
            value={newProject.endDate ? newProject.endDate.split('T')[0] : ''}
            onChange={(e) => handleInputChange('endDate', e.target.value ? new Date(e.target.value).toISOString() : '')}
          />
          <div className="flex items-center">
            <input 
                type="checkbox" 
                id="isFavorite"
                checked={newProject.isFavorite}
                onChange={(e) => handleInputChange('isFavorite', e.target.checked)}
                className={`h-4 w-4 text-[${COLORS.primary}] border-gray-600 rounded focus:ring-[${COLORS.primary}]`}
            />
            <label htmlFor="isFavorite" className="ml-2 text-sm text-gray-300">Mark as favorite</label>
          </div>
          <div className="flex justify-end space-x-3 pt-2">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={handleCreateProject}>Create Project</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};


import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { PlusIcon } from '../components/icons/PlusIcon';
import { MOCK_TASKS, MOCK_PROJECTS, MOCK_USERS, COLORS } from '../constants';
import { TaskCard } from '../components/TaskCard';
import { Task, Project, User } from '../types';
import { TaskDetailModal } from '../components/TaskDetailModal'; // Import the modal
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';


const MyTasksWidget: React.FC<{ tasks: Task[], onTaskClick: (task: Task) => void }> = ({ tasks, onTaskClick }) => {
  const openTasks = tasks.filter(t => t.status !== 'Done').slice(0, 5);
  return (
    <Card title="My Open Tasks" actions={<Button variant="ghost" size="sm">View All</Button>}>
      {openTasks.length === 0 && <p className="text-sm text-gray-400">No open tasks. Great job!</p>}
      <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
        {openTasks.map(task => <TaskCard key={task.taskId} task={task} onClick={() => onTaskClick(task)} />)}
      </div>
    </Card>
  );
};

const RecentActivityWidget: React.FC<{ projects: Project[] }> = ({ projects }) => {
  const recentProjects = projects.slice(0, 3); // Simplified: show first 3 projects
  return (
    <Card title="Recent Project Activity">
      <ul className="space-y-3">
        {recentProjects.map(proj => (
          <li key={proj.projectId} className="text-sm p-2 bg-[#0D1117] rounded-md">
            <span className="font-semibold text-[${COLORS.primary}]">{proj.projectName}</span>
            <span className="text-gray-400"> - {proj.status} (Updated {new Date(proj.endDate).toLocaleDateString()})</span>
          </li>
        ))}
      </ul>
    </Card>
  );
};

const TaskStatusChartWidget: React.FC<{ tasks: Task[] }> = ({ tasks }) => {
  const statusCounts = tasks.reduce((acc, task) => {
    acc[task.status] = (acc[task.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const data = Object.entries(statusCounts).map(([name, value]) => ({ name, value }));
  const chartColors = [COLORS.primary, COLORS.success, COLORS.warning, COLORS.danger, '#6366F1', '#EC4899'];


  return (
    <Card title="Task Status Overview">
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} />
            ))}
          </Pie>
          <Tooltip contentStyle={{ backgroundColor: COLORS.darkBgLighter, border: `1px solid ${COLORS.primary}` }} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </Card>
  );
};


const ProjectProgressWidget: React.FC<{ projects: Project[] }> = ({ projects }) => {
  const data = projects.map(p => {
    const totalTasks = MOCK_TASKS.filter(t => t.projectId === p.projectId).length;
    const completedTasks = MOCK_TASKS.filter(t => t.projectId === p.projectId && t.status === 'Done').length;
    const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    return { name: p.projectName.substring(0,15) + (p.projectName.length > 15 ? '...' : ''), progress };
  });

  return (
    <Card title="Project Progress">
        <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data} layout="vertical" margin={{ top: 5, right: 20, left: 60, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis type="number" domain={[0, 100]} stroke="#9CA3AF" tickFormatter={(value) => `${value}%`} />
                <YAxis dataKey="name" type="category" stroke="#9CA3AF" width={100} interval={0} />
                <Tooltip 
                    contentStyle={{ backgroundColor: COLORS.darkBgLighter, border: `1px solid ${COLORS.primary}`}}
                    formatter={(value: number) => `${value}%`}
                />
                <Bar dataKey="progress" fill={`url(#colorProgress)`} barSize={20}>
                     {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={index % 2 === 0 ? COLORS.primary : COLORS.success} />
                    ))}
                </Bar>
            </BarChart>
        </ResponsiveContainer>
        <svg>
            <defs>
                <linearGradient id="colorProgress" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor={COLORS.primary} stopOpacity={0.8}/>
                    <stop offset="100%" stopColor={COLORS.success} stopOpacity={0.8}/>
                </linearGradient>
            </defs>
        </svg>
    </Card>
  );
};


export const DashboardPage: React.FC = () => {
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS); // Local state for tasks

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
  };

  const handleCloseModal = () => {
    setSelectedTask(null);
  };

  const handleUpdateTask = (updatedTask: Task) => {
    setTasks(prevTasks => prevTasks.map(t => t.taskId === updatedTask.taskId ? updatedTask : t));
    // setSelectedTask(updatedTask); // Keep modal open with updated task
  };


  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-white">Dashboard</h1>
        <Button variant="primary" leftIcon={<PlusIcon className="w-5 h-5" />}>
          Add Widget
        </Button>
      </div>

      {/* Customizable Grid (Static for now) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <MyTasksWidget tasks={tasks} onTaskClick={handleTaskClick} />
        </div>
        <RecentActivityWidget projects={MOCK_PROJECTS} />
        <TaskStatusChartWidget tasks={tasks} />
        <div className="lg:col-span-2">
           <ProjectProgressWidget projects={MOCK_PROJECTS} />
        </div>
      </div>
      
      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          isOpen={!!selectedTask}
          onClose={handleCloseModal}
          onUpdateTask={handleUpdateTask}
        />
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { Tag } from '../types';
import { MOCK_TAGS, COLORS } from '../constants';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { PlusIcon } from '../components/icons/PlusIcon';
import { Modal } from '../components/ui/Modal';
import { getRandomHexColor } from '../utils/helpers';
import { TrashIcon } from '../components/icons/TrashIcon'; // Ensured relative path
import { SettingsIcon } from '../components/icons/SettingsIcon'; // Edit icon (using SettingsIcon as placeholder)


export const AdminManageTagsPage: React.FC = () => {
  const [tags, setTags] = useState<Tag[]>(MOCK_TAGS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTag, setEditingTag] = useState<Tag | null>(null);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState(getRandomHexColor());

  const openModalForCreate = () => {
    setEditingTag(null);
    setNewTagName('');
    setNewTagColor(getRandomHexColor());
    setIsModalOpen(true);
  };

  const openModalForEdit = (tag: Tag) => {
    setEditingTag(tag);
    setNewTagName(tag.tagName);
    setNewTagColor(tag.color);
    setIsModalOpen(true);
  };

  const handleSaveTag = () => {
    if (!newTagName.trim()) return;

    if (editingTag) {
      // Update existing tag
      setTags(tags.map(t => t.tagId === editingTag.tagId ? { ...t, tagName: newTagName, color: newTagColor } : t));
    } else {
      // Create new tag
      const newTag: Tag = {
        tagId: `tag-${Date.now()}`,
        tagName: newTagName,
        color: newTagColor,
      };
      setTags([...tags, newTag]);
    }
    setIsModalOpen(false);
  };
  
  const handleDeleteTag = (tagId: string) => {
    if (window.confirm("Are you sure you want to delete this tag? This action cannot be undone.")) {
        setTags(tags.filter(t => t.tagId !== tagId));
    }
  };


  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Manage Tags</h1>
        <Button variant="primary" leftIcon={<PlusIcon className="w-5 h-5" />} onClick={openModalForCreate}>
          New Tag
        </Button>
      </div>

      <Card>
        {tags.length === 0 ? (
          <p className="text-gray-400">No tags found. Create one!</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-[#0D1117]">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Preview</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Color Hex</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-[${COLORS.darkBgLighter}] divide-y divide-gray-700">
                {tags.map(tag => (
                  <tr key={tag.tagId}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full" style={{ backgroundColor: tag.color, color: parseInt(tag.color.replace("#", ""), 16) > 0xffffff / 2 ? 'black' : 'white' }}>
                        {tag.tagName}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-200">{tag.tagName}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{tag.color}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                      <Button variant="ghost" size="sm" onClick={() => openModalForEdit(tag)} title="Edit">
                        <SettingsIcon className="w-4 h-4" />
                      </Button>
                       <Button variant="ghost" size="sm" onClick={() => handleDeleteTag(tag.tagId)} className="!text-red-500 hover:!text-red-400" title="Delete">
                        <TrashIcon className="w-4 h-4"/>
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
      
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingTag ? "Edit Tag" : "Create New Tag"}>
        <div className="space-y-4">
          <Input 
            label="Tag Name"
            value={newTagName}
            onChange={(e) => setNewTagName(e.target.value)}
            placeholder="Enter tag name"
            required
          />
          <div className="flex items-center space-x-3">
            <Input 
              label="Tag Color"
              type="color"
              value={newTagColor}
              onChange={(e) => setNewTagColor(e.target.value)}
              className="p-1 h-10 w-16" // Specific styling for color input
              wrapperClassName="flex-shrink-0"
            />
            <Input
                label="Hex Code"
                value={newTagColor}
                onChange={(e) => setNewTagColor(e.target.value)}
                placeholder="#RRGGBB"
                className="flex-grow"
            />
          </div>
          <div className="pt-2 flex justify-end space-x-3">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={handleSaveTag}>Save Tag</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
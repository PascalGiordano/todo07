
import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { RichTextEditor } from '../components/ui/RichTextEditor'; // Import RichTextEditor
import { Button } from '../components/ui/Button';
import { COLORS } from '../constants';

export const NotesPage: React.FC = () => {
  const [noteContent, setNoteContent] = useState('');

  return (
    <div>
      <h1 className="text-3xl font-bold text-white mb-6">My Notes</h1>
      <Card title="Create or Edit Note">
        <RichTextEditor
          value={noteContent}
          onChange={setNoteContent}
          placeholder="Start typing your note here..."
          wrapperClassName="mb-4"
          label="Note Content" // Optional label
        />
        <div className="mt-4 flex justify-end">
          <Button variant="primary" onClick={() => alert('Note saved (not really)! Content: ' + noteContent)}>Save Note</Button>
        </div>
      </Card>
    </div>
  );
};

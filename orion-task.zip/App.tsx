
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/layout/Layout';
import { DashboardPage } from './pages/DashboardPage';
import { ProjectsListPage } from './pages/ProjectsListPage';
import { ProjectDetailPage } from './pages/ProjectDetailPage';
import { KanbanViewPage } from './pages/KanbanViewPage';
import { CalendarViewPage } from './pages/CalendarViewPage';
import { NotesPage } from './pages/NotesPage';
import { TeamsPage } from './pages/TeamsPage';
import { AiFeaturesPage } from './pages/AiFeaturesPage';
import { AdminManageTagsPage } from './pages/AdminManageTagsPage';
import { AdminManageCategoriesPage } from './pages/AdminManageCategoriesPage'; // Import new page

// Placeholder for Settings Page
const SettingsPagePlaceholder: React.FC = () => <div className="text-white text-xl p-5 bg-[#0D1117] rounded-md">Settings Page - Content under construction.</div>;


const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<DashboardPage />} />
          <Route path="projects" element={<ProjectsListPage />} />
          <Route path="projects/:projectId" element={<ProjectDetailPage />} /> 
          <Route path="tasks" element={<KanbanViewPage />} />
          <Route path="calendar" element={<CalendarViewPage />} />
          <Route path="notes" element={<NotesPage />} />
          <Route path="teams" element={<TeamsPage />} />
          <Route path="ai-features" element={<AiFeaturesPage />} />
          <Route path="settings" element={<SettingsPagePlaceholder />} />
          <Route path="admin/tags" element={<AdminManageTagsPage />} />
          <Route path="admin/categories" element={<AdminManageCategoriesPage />} /> {/* Add route for categories */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </HashRouter>
  );
};

export default App;
